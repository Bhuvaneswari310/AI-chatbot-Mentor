import { useEffect, useState } from 'react';
import { Sparkles, CheckCircle2, Circle, ArrowUpRight, ArrowDownRight, Minus } from 'lucide-react';
import type { Review, ReviewItem } from '@/lib/types';
import { Button } from '@/components/ui/Button';
import { Badge, severityBadge } from '@/components/ui/Badge';
import { toast } from '@/components/ui/Toast';
import { runReview, fetchReviewItems, toggleReviewItemResolved, approveStudent } from '@/lib/data';
import { formatDateTime } from '@/lib/export';

interface ReviewsTabProps {
  studentId: string;
  studentName: string;
  reviews: Review[];
  onReviewComplete: () => void;
}

export function ReviewsTab({ studentId, studentName, reviews, onReviewComplete }: ReviewsTabProps) {
  const [reviewing, setReviewing] = useState(false);
  const [itemsByReview, setItemsByReview] = useState<Record<string, ReviewItem[]>>({});
  const [expanded, setExpanded] = useState<string | null>(reviews[0]?.id ?? null);

  useEffect(() => {
    const open = expanded ?? reviews[0]?.id;
    if (!open) return;
    if (itemsByReview[open]) return;
    fetchReviewItems(open)
      .then((items) => setItemsByReview((prev) => ({ ...prev, [open]: items })))
      .catch(() => {});
  }, [expanded, reviews, itemsByReview]);

  async function handleReview() {
    setReviewing(true);
    try {
      const result = await runReview(studentId);
      toast(
        result.test_mode
          ? 'Review generated (test mode).'
          : 'AI review complete.',
        result.test_mode ? 'info' : 'success',
      );
      if (result.email_sent) {
        toast('Review email sent to student.', 'success');
      } else if (result.email_error) {
        toast(`Email not sent: ${result.email_error}`, 'warning');
      }
      setExpanded(result.review.id);
      onReviewComplete();
    } catch (e) {
      toast(e instanceof Error ? e.message : 'Review failed', 'error');
    } finally {
      setReviewing(false);
    }
  }

  async function handleToggle(item: ReviewItem) {
    try {
      await toggleReviewItemResolved(item.id, !item.resolved);
      setItemsByReview((prev) => ({
        ...prev,
        [item.review_id]: (prev[item.review_id] ?? []).map((i) =>
          i.id === item.id ? { ...i, resolved: !i.resolved } : i,
        ),
      }));
    } catch (e) {
      toast(e instanceof Error ? e.message : 'Failed to update', 'error');
    }
  }

  async function handleApprove() {
    try {
      await approveStudent(studentId);
      toast(`${studentName} approved.`);
      onReviewComplete();
    } catch (e) {
      toast(e instanceof Error ? e.message : 'Failed to approve', 'error');
    }
  }

  function scoreTone(score: number) {
    if (score >= 85) return 'text-emerald-600';
    if (score >= 60) return 'text-amber-600';
    return 'text-rose-600';
  }

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
        <div>
          <h3 className="text-sm font-semibold">AI Reviews</h3>
          <p className="mt-0.5 text-xs text-slate-500">
            {reviews.length} review{reviews.length !== 1 ? 's' : ''} generated.
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="subtle" size="sm" onClick={handleReview} loading={reviewing}>
            <Sparkles className="h-4 w-4" />
            Run review
          </Button>
          <Button variant="primary" size="sm" onClick={handleApprove}>
            <CheckCircle2 className="h-4 w-4" />
            Mark approved
          </Button>
        </div>
      </div>

      {reviews.length === 0 ? (
        <div className="rounded-xl border border-dashed border-slate-300 bg-white px-6 py-12 text-center">
          <Sparkles className="mx-auto h-8 w-8 text-slate-300" />
          <p className="mt-2 text-sm text-slate-400">
            No reviews yet. Submit a project version and run the AI review.
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {reviews.map((r) => {
            const items = itemsByReview[r.id] ?? [];
            const open = expanded === r.id;
            const errorCount = items.filter((i) => i.severity === 'error' && !i.resolved).length;
            return (
              <div key={r.id} className="rounded-xl border border-slate-200 bg-white shadow-sm overflow-hidden">
                <button
                  onClick={() => setExpanded(open ? null : r.id)}
                  className="flex w-full items-center justify-between px-5 py-4 text-left transition hover:bg-slate-50"
                >
                  <div className="flex items-center gap-3">
                    <div className={`flex h-11 w-11 items-center justify-center rounded-xl text-lg font-bold ${scoreTone(r.score)}`}>
                      {r.score}
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-slate-900">Review #{r.review_number}</p>
                      <p className="text-xs text-slate-400">{formatDateTime(r.created_at)} · {r.ai_model}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {r.state === 'approved' ? <Badge tone="green">Approved</Badge> :
                      r.state === 'ready_for_review' ? <Badge tone="blue">Ready</Badge> :
                      <Badge tone="amber">Needs Correction</Badge>}
                    {errorCount > 0 && <Badge tone="red">{errorCount} open</Badge>}
                  </div>
                </button>

                {open && (
                  <div className="border-t border-slate-100 px-5 py-4 animate-fade-in">
                    {r.summary && (
                      <p className="text-sm text-slate-700 mb-3">{r.summary}</p>
                    )}
                    {(r.what_improved || r.what_remains) && (
                      <div className="mb-4 grid gap-3 sm:grid-cols-2">
                        {r.what_improved && (
                          <div className="rounded-lg bg-emerald-50 p-3">
                            <p className="flex items-center gap-1.5 text-xs font-semibold text-emerald-700">
                              <ArrowUpRight className="h-3.5 w-3.5" /> Improved
                            </p>
                            <p className="mt-1 text-xs text-emerald-800">{r.what_improved}</p>
                          </div>
                        )}
                        {r.what_remains && (
                          <div className="rounded-lg bg-amber-50 p-3">
                            <p className="flex items-center gap-1.5 text-xs font-semibold text-amber-700">
                              <Minus className="h-3.5 w-3.5" /> Remaining
                            </p>
                            <p className="mt-1 text-xs text-amber-800">{r.what_remains}</p>
                          </div>
                        )}
                      </div>
                    )}

                    <p className="text-xs font-semibold uppercase tracking-wide text-slate-400 mb-2">
                      Findings ({items.length})
                    </p>
                    {items.length === 0 ? (
                      <p className="text-sm text-slate-400">Loading findings...</p>
                    ) : (
                      <ul className="space-y-2">
                        {items.map((item) => (
                          <li
                            key={item.id}
                            className={`rounded-lg border p-3 transition ${
                              item.resolved ? 'border-emerald-200 bg-emerald-50/50' : 'border-slate-200 bg-white'
                            }`}
                          >
                            <div className="flex items-start gap-3">
                              <button
                                onClick={() => handleToggle(item)}
                                className="mt-0.5 shrink-0"
                                aria-label="Toggle resolved"
                              >
                                {item.resolved ? (
                                  <CheckCircle2 className="h-5 w-5 text-emerald-500" />
                                ) : (
                                  <Circle className="h-5 w-5 text-slate-300 hover:text-slate-400" />
                                )}
                              </button>
                              <div className="min-w-0 flex-1">
                                <div className="flex flex-wrap items-center gap-2">
                                  {severityBadge(item.severity)}
                                  {item.category && <Badge tone="neutral">{item.category}</Badge>}
                                  {item.resolved && <Badge tone="green">Resolved</Badge>}
                                </div>
                                <p className={`mt-1.5 text-sm font-medium ${item.resolved ? 'text-slate-500 line-through' : 'text-slate-900'}`}>
                                  {item.title}
                                </p>
                                {item.explanation && (
                                  <p className="mt-1 text-xs text-slate-600">
                                    <span className="font-medium text-slate-700">Why: </span>
                                    {item.explanation}
                                  </p>
                                )}
                                {item.fix && (
                                  <p className="mt-1 text-xs text-slate-600">
                                    <span className="font-medium text-blue-700">Fix: </span>
                                    {item.fix}
                                  </p>
                                )}
                              </div>
                            </div>
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
