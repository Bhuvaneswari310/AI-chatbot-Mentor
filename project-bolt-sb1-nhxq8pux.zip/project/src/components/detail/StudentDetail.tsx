import { useEffect, useState } from 'react';
import { ArrowLeft, Mail, Calendar, FileCode, MessageSquare, Sparkles, ClipboardList, CheckCircle2 } from 'lucide-react';
import type { Student, Requirement, Submission, Review, ChatMessage, Schedule, EmailLog } from '@/lib/types';
import { Badge, statusBadge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { toast } from '@/components/ui/Toast';
import {
  fetchRequirements,
  fetchSubmissions,
  fetchReviews,
  fetchChat,
  fetchSchedules,
  fetchEmails,
  runReview,
  approveStudent,
} from '@/lib/data';
import { formatDate, isOverdue } from '@/lib/export';
import { RequirementsTab } from './RequirementsTab';
import { SubmissionsTab } from './SubmissionsTab';
import { ReviewsTab } from './ReviewsTab';
import { ChatTab } from './ChatTab';
import { ScheduleTab } from './ScheduleTab';
import { EmailsTab } from './EmailsTab';

type Tab = 'overview' | 'requirements' | 'submissions' | 'reviews' | 'chat' | 'schedule' | 'emails';

interface DetailProps {
  student: Student;
  allSchedules: Schedule[];
  onBack: () => void;
  onChanged: () => void;
}

const tabs: { key: Tab; label: string; icon: typeof Mail }[] = [
  { key: 'overview', label: 'Overview', icon: ClipboardList },
  { key: 'requirements', label: 'Requirements', icon: ClipboardList },
  { key: 'submissions', label: 'Submissions', icon: FileCode },
  { key: 'reviews', label: 'Reviews', icon: Sparkles },
  { key: 'chat', label: 'AI Mentor', icon: MessageSquare },
  { key: 'schedule', label: 'Schedule', icon: Calendar },
  { key: 'emails', label: 'Emails', icon: Mail },
];

export function StudentDetail({ student, allSchedules, onBack, onChanged }: DetailProps) {
  const [tab, setTab] = useState<Tab>('overview');
  const [requirements, setRequirements] = useState<Requirement[]>([]);
  const [submissions, setSubmissions] = useState<Submission[]>([]);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [schedules, setSchedules] = useState<Schedule[]>([]);
  const [emails, setEmails] = useState<EmailLog[]>([]);
  const [reviewing, setReviewing] = useState(false);

  async function loadAll() {
    const [r, s, rev, c, sch, e] = await Promise.all([
      fetchRequirements(student.id),
      fetchSubmissions(student.id),
      fetchReviews(student.id),
      fetchChat(student.id),
      fetchSchedules(student.id),
      fetchEmails(student.id),
    ]);
    setRequirements(r);
    setSubmissions(s);
    setReviews(rev);
    setMessages(c);
    setSchedules(sch);
    setEmails(e);
  }

  useEffect(() => {
    loadAll();
  }, [student.id]);

  async function handleReview() {
    setReviewing(true);
    try {
      const result = await runReview(student.id);
      toast(result.test_mode ? 'Review generated (test mode).' : 'AI review complete.', result.test_mode ? 'info' : 'success');
      await loadAll();
      setTab('reviews');
      onChanged();
    } catch (e) {
      toast(e instanceof Error ? e.message : 'Review failed', 'error');
    } finally {
      setReviewing(false);
    }
  }

  async function handleApprove() {
    try {
      await approveStudent(student.id);
      toast(`${student.name} approved.`);
      onChanged();
    } catch (e) {
      toast(e instanceof Error ? e.message : 'Failed to approve', 'error');
    }
  }

  const openErrors = reviews[0]
    ? reviews[0].review_items?.filter((i) => i.severity === 'error' && !i.resolved).length ?? 0
    : 0;
  const latestScore = reviews[0]?.score;

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <button onClick={onBack} className="flex items-center gap-1.5 text-sm text-slate-500 transition hover:text-slate-900">
          <ArrowLeft className="h-4 w-4" />
          Back to students
        </button>
      </div>

      <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm sm:p-6">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <h1 className="text-xl font-bold tracking-tight">{student.name}</h1>
              {statusBadge(student.status)}
              {isOverdue(student) && <Badge tone="red">Overdue</Badge>}
            </div>
            <p className="mt-1 text-sm text-slate-600">{student.project_title}</p>
            <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-xs text-slate-400">
              <span>{student.email}</span>
              {student.domain && <span>· {student.domain}</span>}
              {student.assigned_mentor && <span>· Mentor: {student.assigned_mentor}</span>}
              <span className="capitalize">· {student.skill_level}</span>
            </div>
          </div>
          <div className="flex gap-2">
            <Button variant="subtle" size="sm" onClick={handleReview} loading={reviewing}>
              <Sparkles className="h-4 w-4" />
              Run AI review
            </Button>
            <Button size="sm" onClick={handleApprove}>
              <CheckCircle2 className="h-4 w-4" />
              Approve
            </Button>
          </div>
        </div>

        <div className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-4">
          <Stat label="Latest score" value={latestScore != null ? `${latestScore}/100` : '—'} />
          <Stat label="Open errors" value={openErrors} />
          <Stat label="Submissions" value={submissions.length} />
          <Stat label="Reviews" value={reviews.length} />
        </div>
      </div>

      <div className="border-b border-slate-200">
        <nav className="flex gap-1 overflow-x-auto">
          {tabs.map((t) => {
            const Icon = t.icon;
            const active = tab === t.key;
            return (
              <button
                key={t.key}
                onClick={() => setTab(t.key)}
                className={`flex items-center gap-1.5 whitespace-nowrap border-b-2 px-3.5 py-2.5 text-sm font-medium transition ${
                  active
                    ? 'border-blue-600 text-blue-700'
                    : 'border-transparent text-slate-500 hover:border-slate-300 hover:text-slate-700'
                }`}
              >
                <Icon className="h-4 w-4" />
                {t.label}
              </button>
            );
          })}
        </nav>
      </div>

      <div>
        {tab === 'overview' && (
          <OverviewTab
            student={student}
            requirements={requirements}
            submissions={submissions}
            reviews={reviews}
            schedules={schedules}
            onGoTo={setTab}
          />
        )}
        {tab === 'requirements' && (
          <RequirementsTab studentId={student.id} requirements={requirements} onChanged={loadAll} />
        )}
        {tab === 'submissions' && (
          <SubmissionsTab studentId={student.id} submissions={submissions} onChanged={loadAll} onReviewComplete={loadAll} />
        )}
        {tab === 'reviews' && (
          <ReviewsTab studentId={student.id} studentName={student.name} reviews={reviews} onReviewComplete={loadAll} />
        )}
        {tab === 'chat' && (
          <ChatTab studentId={student.id} studentName={student.name} messages={messages} onChated={loadAll} />
        )}
        {tab === 'schedule' && (
          <ScheduleTab studentId={student.id} studentName={student.name} schedules={schedules} allSchedules={allSchedules} onChanged={loadAll} />
        )}
        {tab === 'emails' && (
          <EmailsTab studentId={student.id} studentName={student.name} emails={emails} onChanged={loadAll} />
        )}
      </div>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="rounded-xl bg-slate-50 px-4 py-3">
      <p className="text-lg font-bold text-slate-900">{value}</p>
      <p className="text-xs text-slate-500">{label}</p>
    </div>
  );
}

function OverviewTab({
  student,
  requirements,
  submissions,
  reviews,
  schedules,
  onGoTo,
}: {
  student: Student;
  requirements: Requirement[];
  submissions: Submission[];
  reviews: Review[];
  schedules: Schedule[];
  onGoTo: (t: Tab) => void;
}) {
  const upcoming = schedules.filter((s) => new Date(s.review_at) > new Date())[0];
  const latest = reviews[0];

  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-semibold">Project info</h3>
        </div>
        <dl className="mt-3 space-y-2 text-sm">
          <Row label="Domain" value={student.domain ?? '—'} />
          <Row label="Mentor" value={student.assigned_mentor ?? '—'} />
          <Row label="Skill level" value={<span className="capitalize">{student.skill_level}</span>} />
          <Row label="Start date" value={formatDate(student.start_date)} />
          <Row label="Expected completion" value={formatDate(student.expected_completion_date)} />
          <Row label="Requirements" value={`${requirements.length} defined`} />
        </dl>
      </div>

      <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
        <h3 className="text-sm font-semibold">Latest review</h3>
        {latest ? (
          <div className="mt-3 space-y-2 text-sm">
            <Row label="Score" value={`${latest.score}/100`} />
            <Row label="State" value={statusBadge(latest.state)} />
            <Row label="Review #" value={latest.review_number} />
            <Row label="Date" value={formatDate(latest.created_at)} />
            {latest.summary && <p className="mt-2 text-xs text-slate-600">{latest.summary}</p>}
          </div>
        ) : (
          <p className="mt-3 text-sm text-slate-400">No reviews yet. Run an AI review after a submission.</p>
        )}
        <Button size="sm" variant="ghost" className="mt-3" onClick={() => onGoTo('reviews')}>
          View all reviews →
        </Button>
      </div>

      <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
        <h3 className="text-sm font-semibold">Next scheduled review</h3>
        {upcoming ? (
          <div className="mt-3 space-y-2 text-sm">
            <Row label="Date" value={formatDate(upcoming.review_at)} />
            <Row label="Format" value={upcoming.mode === 'online' ? 'Online' : 'In person'} />
            {upcoming.venue && <Row label="Venue" value={upcoming.venue} />}
            {upcoming.meet_url && <Row label="Link" value={<a href={upcoming.meet_url} target="_blank" rel="noreferrer" className="text-blue-600 hover:underline">Join</a>} />}
          </div>
        ) : (
          <p className="mt-3 text-sm text-slate-400">No upcoming review scheduled.</p>
        )}
        <Button size="sm" variant="ghost" className="mt-3" onClick={() => onGoTo('schedule')}>
          Manage schedule →
        </Button>
      </div>

      <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
        <h3 className="text-sm font-semibold">Submissions</h3>
        <p className="mt-2 text-2xl font-bold text-slate-900">{submissions.length}</p>
        <p className="text-xs text-slate-500">versioned submissions</p>
        <Button size="sm" variant="ghost" className="mt-3" onClick={() => onGoTo('submissions')}>
          View submissions →
        </Button>
      </div>
    </div>
  );
}

function Row({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-3">
      <dt className="text-slate-500">{label}</dt>
      <dd className="font-medium text-slate-900 text-right">{value}</dd>
    </div>
  );
}
