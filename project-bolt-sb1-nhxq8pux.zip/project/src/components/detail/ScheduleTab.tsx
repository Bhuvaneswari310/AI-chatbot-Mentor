import { useState } from 'react';
import { CalendarPlus, Trash2, Video, MapPin, Calendar, Clock, AlertTriangle } from 'lucide-react';
import type { Schedule } from '@/lib/types';
import { Button } from '@/components/ui/Button';
import { Input, Select } from '@/components/ui/Field';
import { Badge } from '@/components/ui/Badge';
import { toast } from '@/components/ui/Toast';
import { upsertSchedule, deleteSchedule, renderEmail } from '@/lib/data';
import { formatDateTime, formatDate } from '@/lib/export';

interface ScheduleTabProps {
  studentId: string;
  studentName: string;
  schedules: Schedule[];
  allSchedules: Schedule[];
  onChanged: () => void;
}

function toLocalInput(d: Date): string {
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

export function ScheduleTab({ studentId, studentName, schedules, allSchedules, onChanged }: ScheduleTabProps) {
  const [reviewAt, setReviewAt] = useState('');
  const [mode, setMode] = useState<'online' | 'in_person'>('online');
  const [venue, setVenue] = useState('');
  const [meetUrl, setMeetUrl] = useState('');
  const [deadline, setDeadline] = useState('');
  const [reminderDays, setReminderDays] = useState(2);
  const [saving, setSaving] = useState(false);

  const conflict = (() => {
    if (!reviewAt) return null;
    const newTime = new Date(reviewAt).getTime();
    const window = 30 * 60 * 1000;
    return allSchedules.find(
      (s) => s.student_id !== studentId && Math.abs(new Date(s.review_at).getTime() - newTime) < window,
    );
  })();

  async function handleSave() {
    if (!reviewAt) {
      toast('Pick a review date and time.', 'warning');
      return;
    }
    if (mode === 'online' && !meetUrl.trim()) {
      toast('Add a meeting link for an online review, or switch to in-person.', 'warning');
      return;
    }
    if (mode === 'in_person' && !venue.trim()) {
      toast('Add a venue for an in-person review.', 'warning');
      return;
    }
    setSaving(true);
    try {
      await upsertSchedule(studentId, {
        review_at: new Date(reviewAt).toISOString(),
        mode,
        venue: mode === 'in_person' ? venue : null,
        meet_url: mode === 'online' ? meetUrl : null,
        submission_deadline: deadline || null,
        reminder_interval_days: reminderDays,
      });
      toast('Review scheduled.');
      setReviewAt('');
      setVenue('');
      setMeetUrl('');
      setDeadline('');
      onChanged();
    } catch (e) {
      toast(e instanceof Error ? e.message : 'Failed to schedule', 'error');
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(id: string) {
    try {
      await deleteSchedule(id);
      toast('Schedule removed.');
      onChanged();
    } catch (e) {
      toast(e instanceof Error ? e.message : 'Failed to delete', 'error');
    }
  }

  async function handleNotify(type: 'reminder' | 'overdue' | 'approval') {
    try {
      const res = await renderEmail(studentId, type);
      toast(`Email drafted: "${res.subject}"`);
      onChanged();
    } catch (e) {
      toast(e instanceof Error ? e.message : 'Failed to generate email', 'error');
    }
  }

  const upcoming = schedules.filter((s) => new Date(s.review_at) > new Date());
  const past = schedules.filter((s) => new Date(s.review_at) <= new Date());

  return (
    <div className="space-y-5">
      <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
        <div className="flex items-center gap-2">
          <CalendarPlus className="h-4 w-4 text-blue-500" />
          <h3 className="text-sm font-semibold">Schedule a review for {studentName}</h3>
        </div>
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          <Input
            label="Review date & time"
            type="datetime-local"
            value={reviewAt}
            onChange={(e) => setReviewAt(e.target.value)}
          />
          <Select
            label="Format"
            value={mode}
            onChange={(e) => setMode(e.target.value as 'online' | 'in_person')}
          >
            <option value="online">Online (video call)</option>
            <option value="in_person">In person</option>
          </Select>
          {mode === 'online' ? (
            <Input
              label="Meeting link (Google Meet / Zoom)"
              value={meetUrl}
              onChange={(e) => setMeetUrl(e.target.value)}
              placeholder="https://meet.google.com/xxx-yyyy-zzz"
            />
          ) : (
            <Input
              label="Venue"
              value={venue}
              onChange={(e) => setVenue(e.target.value)}
              placeholder="Conference Room B, 3rd Floor"
            />
          )}
          <Input
            label="Submission deadline"
            type="date"
            value={deadline}
            onChange={(e) => setDeadline(e.target.value)}
          />
          <Input
            label="Reminder (days before)"
            type="number"
            min={0}
            max={14}
            value={reminderDays}
            onChange={(e) => setReminderDays(Number(e.target.value))}
          />
        </div>

        {conflict && (
          <div className="mt-3 flex items-start gap-2 rounded-lg bg-amber-50 px-3 py-2 text-xs text-amber-700 ring-1 ring-inset ring-amber-200">
            <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
            <span>
              Another student has a review within 30 minutes of this time. Consider spacing them out to avoid a scheduling conflict.
            </span>
          </div>
        )}

        <div className="mt-4">
          <Button onClick={handleSave} loading={saving}>
            <CalendarPlus className="h-4 w-4" />
            Schedule review
          </Button>
        </div>
      </div>

      {schedules.length > 0 && (
        <div className="flex flex-wrap gap-2 rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
          <span className="self-center text-xs font-medium text-slate-500">Quick email:</span>
          <Button size="sm" variant="subtle" onClick={() => handleNotify('reminder')}>Reminder</Button>
          <Button size="sm" variant="subtle" onClick={() => handleNotify('overdue')}>Overdue notice</Button>
          <Button size="sm" variant="subtle" onClick={() => handleNotify('approval')}>Approval</Button>
        </div>
      )}

      <div className="rounded-xl border border-slate-200 bg-white shadow-sm">
        <div className="border-b border-slate-100 px-5 py-3">
          <h3 className="text-sm font-semibold">Scheduled reviews ({schedules.length})</h3>
        </div>
        {schedules.length === 0 ? (
          <p className="px-5 py-8 text-center text-sm text-slate-400">
            No reviews scheduled yet.
          </p>
        ) : (
          <ul className="divide-y divide-slate-50">
            {[...upcoming, ...past].map((s) => {
              const isUpcoming = new Date(s.review_at) > new Date();
              return (
                <li key={s.id} className="flex items-start justify-between px-5 py-4">
                  <div className="flex gap-3">
                    <div className={`flex h-10 w-10 items-center justify-center rounded-lg ${isUpcoming ? 'bg-blue-50 text-blue-600' : 'bg-slate-100 text-slate-400'}`}>
                      {s.mode === 'online' ? <Video className="h-5 w-5" /> : <MapPin className="h-5 w-5" />}
                    </div>
                    <div>
                      <p className="flex items-center gap-1.5 text-sm font-medium text-slate-900">
                        <Calendar className="h-3.5 w-3.5 text-slate-400" />
                        {formatDateTime(s.review_at)}
                      </p>
                      <p className="mt-0.5 text-xs text-slate-500">
                        {s.mode === 'online' ? 'Online meeting' : `In person — ${s.venue ?? 'venue TBD'}`}
                      </p>
                      {s.meet_url && (
                        <a href={s.meet_url} target="_blank" rel="noreferrer" className="mt-1 inline-block text-xs text-blue-600 hover:underline">
                          Join meeting
                        </a>
                      )}
                      {s.submission_deadline && (
                        <p className="mt-1 flex items-center gap-1 text-xs text-slate-400">
                          <Clock className="h-3 w-3" /> Submit by {formatDate(s.submission_deadline)}
                        </p>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {isUpcoming ? <Badge tone="blue">Upcoming</Badge> : <Badge tone="neutral">Past</Badge>}
                    <button
                      onClick={() => handleDelete(s.id)}
                      className="rounded-lg p-1.5 text-slate-300 transition hover:bg-rose-50 hover:text-rose-600"
                      aria-label="Delete schedule"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </div>
  );
}
