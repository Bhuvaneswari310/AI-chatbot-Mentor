import { useState } from 'react';
import { Mail, Send, Copy, Download, Bell, AlertTriangle, CheckCircle2, RotateCcw, Zap } from 'lucide-react';
import type { EmailLog } from '@/lib/types';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Field';
import { Badge } from '@/components/ui/Badge';
import { Modal } from '@/components/ui/Modal';
import { toast } from '@/components/ui/Toast';
import { renderEmail, markEmailSent, sendEmail, sendTestEmail } from '@/lib/data';
import { formatDateTime, downloadText } from '@/lib/export';

interface EmailsTabProps {
  studentId: string;
  studentName: string;
  emails: EmailLog[];
  onChanged: () => void;
}

const typeMeta: Record<string, { label: string; tone: 'blue' | 'amber' | 'green' | 'red' | 'neutral'; icon: typeof Mail }> = {
  review_update: { label: 'Review Update', tone: 'blue', icon: Mail },
  reminder: { label: 'Reminder', tone: 'amber', icon: Bell },
  overdue: { label: 'Overdue', tone: 'red', icon: AlertTriangle },
  resubmission: { label: 'Resubmission', tone: 'neutral', icon: RotateCcw },
  approval: { label: 'Approval', tone: 'green', icon: CheckCircle2 },
};

export function EmailsTab({ studentId, studentName, emails, onChanged }: EmailsTabProps) {
  const [viewing, setViewing] = useState<EmailLog | null>(null);
  const [generating, setGenerating] = useState<string | null>(null);
  const [sendingId, setSendingId] = useState<string | null>(null);
  const [testOpen, setTestOpen] = useState(false);
  const [testTo, setTestTo] = useState('');
  const [testSending, setTestSending] = useState(false);

  async function handleGenerate(type: 'reminder' | 'overdue' | 'resubmission' | 'approval') {
    setGenerating(type);
    try {
      const res = await renderEmail(studentId, type);
      toast(`Email drafted: "${res.subject}"`);
      onChanged();
    } catch (e) {
      toast(e instanceof Error ? e.message : 'Failed to generate email', 'error');
    } finally {
      setGenerating(null);
    }
  }

  async function handleSend(email: EmailLog) {
    setSendingId(email.id);
    try {
      const res = await sendEmail(email.id);
      if (res.ok) {
        toast(`Email sent to ${res.sent_to ?? 'student'}.`);
        onChanged();
      } else {
        toast(res.error ?? 'Failed to send email', 'error');
      }
    } catch (e) {
      toast(e instanceof Error ? e.message : 'Failed to send', 'error');
    } finally {
      setSendingId(null);
    }
  }

  async function handleMarkSent(id: string) {
    try {
      await markEmailSent(id);
      toast('Marked as sent.');
      onChanged();
    } catch (e) {
      toast(e instanceof Error ? e.message : 'Failed to update', 'error');
    }
  }

  async function handleTestSend() {
    setTestSending(true);
    try {
      const res = await sendTestEmail(testTo.trim() || undefined);
      if (res.ok) {
        toast(`Test email sent to ${res.sent_to ?? 'your SMTP from-address'}.`);
        setTestOpen(false);
        setTestTo('');
      } else if (res.configured === false) {
        toast('SMTP is not configured. Add SMTP secrets first — see Settings tab.', 'warning');
      } else {
        toast(res.error ?? 'Test email failed', 'error');
      }
    } catch (e) {
      toast(e instanceof Error ? e.message : 'Test email failed', 'error');
    } finally {
      setTestSending(false);
    }
  }

  function handleCopy(email: EmailLog) {
    const text = `Subject: ${email.subject}\n\n${email.body}`;
    navigator.clipboard.writeText(text).then(
      () => toast('Email copied to clipboard.'),
      () => toast('Copy failed.', 'error'),
    );
  }

  return (
    <div className="space-y-5">
      <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
        <div className="flex items-center gap-2">
          <Mail className="h-4 w-4 text-blue-500" />
          <h3 className="text-sm font-semibold">Generate email notification</h3>
        </div>
        <p className="mt-0.5 text-xs text-slate-500">
          Each email is personalized for {studentName}. Generated emails can be sent directly to the student's registered address once SMTP is configured.
        </p>
        <div className="mt-3 flex flex-wrap gap-2">
          <Button size="sm" variant="secondary" onClick={() => setTestOpen(true)}>
            <Zap className="h-4 w-4" /> Send test email
          </Button>
          <Button size="sm" variant="subtle" onClick={() => handleGenerate('reminder')} loading={generating === 'reminder'}>
            <Bell className="h-4 w-4" /> Reminder
          </Button>
          <Button size="sm" variant="subtle" onClick={() => handleGenerate('overdue')} loading={generating === 'overdue'}>
            <AlertTriangle className="h-4 w-4" /> Overdue notice
          </Button>
          <Button size="sm" variant="subtle" onClick={() => handleGenerate('resubmission')} loading={generating === 'resubmission'}>
            <RotateCcw className="h-4 w-4" /> Resubmission
          </Button>
          <Button size="sm" variant="subtle" onClick={() => handleGenerate('approval')} loading={generating === 'approval'}>
            <CheckCircle2 className="h-4 w-4" /> Approval
          </Button>
        </div>
      </div>

      <div className="rounded-xl border border-slate-200 bg-white shadow-sm">
        <div className="border-b border-slate-100 px-5 py-3">
          <h3 className="text-sm font-semibold">Email history ({emails.length})</h3>
        </div>
        {emails.length === 0 ? (
          <p className="px-5 py-8 text-center text-sm text-slate-400">
            No emails yet. Review-update emails are generated automatically after each AI review.
          </p>
        ) : (
          <ul className="divide-y divide-slate-50">
            {emails.map((e) => {
              const meta = typeMeta[e.email_type] ?? typeMeta.review_update;
              const Icon = meta.icon;
              return (
                <li key={e.id} className="px-5 py-3">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex gap-3">
                      <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-slate-100">
                        <Icon className="h-4 w-4 text-slate-500" />
                      </div>
                      <div className="min-w-0">
                        <p className="truncate text-sm font-medium text-slate-900">{e.subject}</p>
                        <p className="text-xs text-slate-400">{formatDateTime(e.created_at)}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge tone={meta.tone}>{meta.label}</Badge>
                      {e.sent ? <Badge tone="green">Sent</Badge> : <Badge tone="neutral">Draft</Badge>}
                    </div>
                  </div>
                  <div className="mt-2 flex gap-1.5 pl-12">
                    <button onClick={() => setViewing(e)} className="rounded-md px-2 py-1 text-xs text-blue-600 hover:bg-blue-50">
                      View
                    </button>
                    <button onClick={() => handleCopy(e)} className="flex items-center gap-1 rounded-md px-2 py-1 text-xs text-slate-500 hover:bg-slate-100">
                      <Copy className="h-3 w-3" /> Copy
                    </button>
                    <button
                      onClick={() => downloadText(`email_${e.email_type}_${studentName.replace(/\s+/g, '_')}.txt`, `Subject: ${e.subject}\n\n${e.body}`)}
                      className="flex items-center gap-1 rounded-md px-2 py-1 text-xs text-slate-500 hover:bg-slate-100"
                    >
                      <Download className="h-3 w-3" /> Download
                    </button>
                    {!e.sent && (
                      <button
                        onClick={() => handleSend(e)}
                        disabled={sendingId === e.id}
                        className="flex items-center gap-1 rounded-md px-2 py-1 text-xs text-blue-600 hover:bg-blue-50 disabled:opacity-50"
                      >
                        {sendingId === e.id ? (
                          <svg className="h-3 w-3 animate-spin" viewBox="0 0 24 24" fill="none">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z" />
                          </svg>
                        ) : (
                          <Send className="h-3 w-3" />
                        )}
                        Send
                      </button>
                    )}
                    {!e.sent && (
                      <button
                        onClick={() => handleMarkSent(e.id)}
                        className="flex items-center gap-1 rounded-md px-2 py-1 text-xs text-slate-400 hover:bg-slate-100"
                      >
                        Mark sent
                      </button>
                    )}
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </div>

      <Modal open={!!viewing} onClose={() => setViewing(null)} title={viewing?.subject ?? 'Email'} size="lg">
        {viewing && (
          <div>
            <div className="mb-3 flex gap-2">
              <Button size="sm" variant="secondary" onClick={() => handleCopy(viewing)}>
                <Copy className="h-4 w-4" /> Copy
              </Button>
              {!viewing.sent && (
                <Button size="sm" onClick={() => { handleSend(viewing).then(() => setViewing(null)); }} loading={sendingId === viewing.id}>
                  <Send className="h-4 w-4" /> Send to student
                </Button>
              )}
              {!viewing.sent && (
                <Button size="sm" variant="ghost" onClick={() => { handleMarkSent(viewing.id); setViewing(null); }}>
                  Mark as sent
                </Button>
              )}
            </div>
            <pre className="max-h-[60vh] overflow-auto whitespace-pre-wrap rounded-lg bg-slate-50 p-4 text-sm text-slate-700 ring-1 ring-inset ring-slate-200 scrollbar-thin">
              {viewing.body}
            </pre>
          </div>
        )}
      </Modal>

      <Modal open={testOpen} onClose={() => setTestOpen(false)} title="Send test email" size="sm">
        <p className="text-sm text-slate-600">
          This sends a test message to verify your SMTP configuration. Leave the address blank to send to your SMTP from-address.
        </p>
        <div className="mt-4">
          <Input
            label="Send to (optional)"
            type="email"
            value={testTo}
            onChange={(e) => setTestTo(e.target.value)}
            placeholder="your-email@example.com"
            hint="If empty, the test goes to the configured SMTP from-address."
          />
        </div>
        <div className="mt-5 flex justify-end gap-3">
          <Button variant="secondary" onClick={() => setTestOpen(false)}>Cancel</Button>
          <Button onClick={handleTestSend} loading={testSending}>
            <Zap className="h-4 w-4" /> Send test
          </Button>
        </div>
      </Modal>
    </div>
  );
}
