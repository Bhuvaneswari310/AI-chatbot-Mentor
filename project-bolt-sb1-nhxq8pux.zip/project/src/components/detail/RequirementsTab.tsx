import { useState } from 'react';
import { Plus, Trash2, CheckCircle2, Circle } from 'lucide-react';
import type { Requirement } from '@/lib/types';
import { Button } from '@/components/ui/Button';
import { Input, Textarea } from '@/components/ui/Field';
import { Badge } from '@/components/ui/Badge';
import { toast } from '@/components/ui/Toast';
import { addRequirement, deleteRequirement } from '@/lib/data';

interface RequirementsTabProps {
  studentId: string;
  requirements: Requirement[];
  onChanged: () => void;
}

export function RequirementsTab({ studentId, requirements, onChanged }: RequirementsTabProps) {
  const [description, setDescription] = useState('');
  const [mandatory, setMandatory] = useState(true);
  const [saving, setSaving] = useState(false);

  async function handleAdd() {
    if (!description.trim()) {
      toast('Enter a requirement description.', 'warning');
      return;
    }
    setSaving(true);
    try {
      await addRequirement(studentId, description.trim(), mandatory);
      setDescription('');
      toast('Requirement added.');
      onChanged();
    } catch (e) {
      toast(e instanceof Error ? e.message : 'Failed to add', 'error');
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(id: string) {
    try {
      await deleteRequirement(id);
      toast('Requirement removed.');
      onChanged();
    } catch (e) {
      toast(e instanceof Error ? e.message : 'Failed to delete', 'error');
    }
  }

  const mandatoryCount = requirements.filter((r) => r.is_mandatory).length;

  return (
    <div className="space-y-5">
      <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
        <h3 className="text-sm font-semibold text-slate-900">Add a project requirement</h3>
        <p className="mt-0.5 text-xs text-slate-500">
          Define what the project must deliver. The AI checks each submission against these.
        </p>
        <div className="mt-3 space-y-3">
          <Textarea
            placeholder="e.g. The application must allow users to add, edit, and delete inventory items with form validation."
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={3}
          />
          <div className="flex items-center justify-between">
            <label className="flex items-center gap-2 text-sm text-slate-600">
              <input
                type="checkbox"
                checked={mandatory}
                onChange={(e) => setMandatory(e.target.checked)}
                className="h-4 w-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
              />
              Mandatory
            </label>
            <Button size="sm" onClick={handleAdd} loading={saving}>
              <Plus className="h-4 w-4" />
              Add requirement
            </Button>
          </div>
        </div>
      </div>

      <div className="rounded-xl border border-slate-200 bg-white shadow-sm">
        <div className="flex items-center justify-between border-b border-slate-100 px-5 py-3">
          <h3 className="text-sm font-semibold">Defined requirements ({requirements.length})</h3>
          <p className="text-xs text-slate-400">{mandatoryCount} mandatory</p>
        </div>
        {requirements.length === 0 ? (
          <p className="px-5 py-8 text-center text-sm text-slate-400">
            No requirements yet. Add at least one so the AI knows what to review against.
          </p>
        ) : (
          <ul className="divide-y divide-slate-50">
            {requirements.map((r) => (
              <li key={r.id} className="flex items-start gap-3 px-5 py-3">
                {r.is_mandatory ? (
                  <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-blue-500" />
                ) : (
                  <Circle className="mt-0.5 h-4 w-4 shrink-0 text-slate-300" />
                )}
                <div className="min-w-0 flex-1">
                  <p className="text-sm text-slate-700">{r.description}</p>
                  <div className="mt-1">
                    {r.is_mandatory ? <Badge tone="blue">Mandatory</Badge> : <Badge tone="neutral">Optional</Badge>}
                  </div>
                </div>
                <button
                  onClick={() => handleDelete(r.id)}
                  className="rounded-lg p-1.5 text-slate-300 transition hover:bg-rose-50 hover:text-rose-600"
                  aria-label="Delete requirement"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
