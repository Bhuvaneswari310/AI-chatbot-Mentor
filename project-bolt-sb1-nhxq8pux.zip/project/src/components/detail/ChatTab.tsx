import { useEffect, useRef, useState } from 'react';
import { Send, Bot, User as UserIcon } from 'lucide-react';
import type { ChatMessage } from '@/lib/types';
import { Button } from '@/components/ui/Button';
import { toast } from '@/components/ui/Toast';
import { sendChat } from '@/lib/data';

interface ChatTabProps {
  studentId: string;
  studentName: string;
  messages: ChatMessage[];
  onChated: () => void;
}

export function ChatTab({ studentId, studentName, messages, onChated }: ChatTabProps) {
  const [input, setInput] = useState('');
  const [sending, setSending] = useState(false);
  const [testMode, setTestMode] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, sending]);

  async function handleSend() {
    if (!input.trim() || sending) return;
    const text = input.trim();
    setInput('');
    setSending(true);
    try {
      const res = await sendChat(studentId, text);
      setTestMode(res.test_mode);
      onChated();
    } catch (e) {
      setInput(text);
      toast(e instanceof Error ? e.message : 'Failed to send', 'error');
    } finally {
      setSending(false);
    }
  }

  return (
    <div className="flex flex-col rounded-xl border border-slate-200 bg-white shadow-sm" style={{ height: '600px' }}>
      <div className="flex items-center justify-between border-b border-slate-100 px-5 py-3">
        <div className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-blue-600 text-white">
            <Bot className="h-4 w-4" />
          </div>
          <div>
            <p className="text-sm font-semibold">AI Mentor</p>
            <p className="text-xs text-slate-400">Personalized guidance for {studentName}</p>
          </div>
        </div>
        {testMode && (
          <span className="rounded-full bg-amber-50 px-2.5 py-0.5 text-xs font-medium text-amber-700 ring-1 ring-inset ring-amber-200">
            Test mode
          </span>
        )}
      </div>

      <div className="flex-1 space-y-4 overflow-y-auto px-5 py-4 scrollbar-thin">
        {messages.length === 0 ? (
          <div className="flex h-full flex-col items-center justify-center text-center">
            <Bot className="h-10 w-10 text-slate-300" />
            <p className="mt-2 text-sm text-slate-400">
              Start a conversation with the AI mentor. Ask about a review finding, a bug, or a concept you're stuck on.
            </p>
          </div>
        ) : (
          messages.map((m) => (
            <div
              key={m.id}
              className={`flex gap-3 ${m.role === 'student' ? 'flex-row-reverse' : ''}`}
            >
              <div
                className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-lg ${
                  m.role === 'mentor' ? 'bg-blue-600 text-white' : 'bg-slate-200 text-slate-600'
                }`}
              >
                {m.role === 'mentor' ? <Bot className="h-4 w-4" /> : <UserIcon className="h-4 w-4" />}
              </div>
              <div
                className={`max-w-[80%] rounded-2xl px-4 py-2.5 text-sm ${
                  m.role === 'mentor'
                    ? 'bg-slate-100 text-slate-800'
                    : 'bg-blue-600 text-white'
                }`}
              >
                <p className="whitespace-pre-wrap leading-relaxed">{m.content}</p>
              </div>
            </div>
          ))
        )}
        {sending && (
          <div className="flex gap-3">
            <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-blue-600 text-white">
              <Bot className="h-4 w-4" />
            </div>
            <div className="rounded-2xl bg-slate-100 px-4 py-3">
              <div className="flex gap-1">
                <span className="h-2 w-2 animate-pulse-dot rounded-full bg-slate-400" style={{ animationDelay: '0ms' }} />
                <span className="h-2 w-2 animate-pulse-dot rounded-full bg-slate-400" style={{ animationDelay: '200ms' }} />
                <span className="h-2 w-2 animate-pulse-dot rounded-full bg-slate-400" style={{ animationDelay: '400ms' }} />
              </div>
            </div>
          </div>
        )}
        <div ref={endRef} />
      </div>

      <div className="border-t border-slate-100 p-3">
        <div className="flex items-end gap-2">
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSend();
              }
            }}
            placeholder="Type a message... (Enter to send, Shift+Enter for newline)"
            rows={1}
            className="max-h-32 flex-1 resize-none rounded-xl border-0 bg-slate-50 px-3.5 py-2.5 text-sm text-slate-900 ring-1 ring-inset ring-slate-200 placeholder:text-slate-400 focus:ring-2 focus:ring-inset focus:ring-blue-500"
          />
          <Button onClick={handleSend} loading={sending} className="!h-10 !w-10 !px-0">
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
