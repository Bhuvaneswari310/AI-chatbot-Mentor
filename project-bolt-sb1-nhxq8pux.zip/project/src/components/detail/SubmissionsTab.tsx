import { useState } from 'react';
import { Upload, FileCode, Clock, Sparkles } from 'lucide-react';
import type { Submission } from '@/lib/types';
import { Button } from '@/components/ui/Button';
import { Textarea, Input } from '@/components/ui/Field';
import { Badge } from '@/components/ui/Badge';
import { toast } from '@/components/ui/Toast';
import { addSubmission, runReview } from '@/lib/data';
import { formatDateTime } from '@/lib/export';

interface SubmissionsTabProps {
  studentId: string;
  submissions: Submission[];
  onChanged: () => void;
  onReviewComplete: () => void;
}

export function SubmissionsTab({ studentId, submissions, onChanged, onReviewComplete }: SubmissionsTabProps) {
  const [filename, setFilename] = useState('');
  const [fileType, setFileType] = useState('python');
  const [content, setContent] = useState('');
  const [notes, setNotes] = useState('');
  const [saving, setSaving] = useState(false);
  const [reviewing, setReviewing] = useState(false);

  async function handleSubmit() {
    if (!filename.trim() || !content.trim()) {
      toast('Filename and content are required.', 'warning');
      return;
    }
    setSaving(true);
    try {
      await addSubmission(studentId, filename.trim(), fileType, content, notes);
      setFilename('');
      setContent('');
      setNotes('');
      toast('Submission uploaded.');
      onChanged();
    } catch (e) {
      toast(e instanceof Error ? e.message : 'Failed to submit', 'error');
    } finally {
      setSaving(false);
    }
  }

  async function handleReview() {
    setReviewing(true);
    try {
      const result = await runReview(studentId);
      toast(
        result.test_mode
          ? 'Review generated (test mode — no LLM key configured).'
          : 'AI review complete.',
        result.test_mode ? 'info' : 'success',
      );
      onReviewComplete();
    } catch (e) {
      toast(e instanceof Error ? e.message : 'Review failed', 'error');
    } finally {
      setReviewing(false);
    }
  }

  const hasSubmissions = submissions.length > 0;

  return (
    <div className="space-y-5">
      <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
        <div className="flex items-center gap-2">
          <Upload className="h-4 w-4 text-blue-500" />
          <h3 className="text-sm font-semibold">Submit a project version</h3>
        </div>
        <p className="mt-0.5 text-xs text-slate-500">
          Paste the source code or report content. Each submission is versioned automatically.
        </p>
        <div className="mt-3 grid gap-3 sm:grid-cols-2">
          <Input
            label="File name"
            value={filename}
            onChange={(e) => setFilename(e.target.value)}
            placeholder="main.py"
          />
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">File type</label>
            <select
              value={fileType}
              onChange={(e) => setFileType(e.target.value)}
              className="w-full rounded-lg border-0 bg-white px-3.5 py-2.5 text-slate-900 ring-1 ring-inset ring-slate-300 focus:ring-2 focus:ring-inset focus:ring-blue-500 shadow-sm"
            >
              <option value="python">Python</option>
              <option value="javascript">JavaScript</option>
              <option value="java">Java</option>
              <option value="cpp">C/C++</option>
              <option value="sql">SQL</option>
              <option value="html">HTML</option>
              <option value="css">CSS</option>
              <option value="text">Text / Report</option>
            </select>
          </div>
        </div>
        <div className="mt-3">
          <Textarea
            label="Content (source code or report text)"
            value={content}
            onChange={(e) => setContent(e.target.value)}
            rows={10}
            placeholder="Paste the project content here..."
            className="font-mono text-xs"
          />
        </div>
        <div className="mt-3">
          <Textarea
            label="Notes (optional)"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            rows={2}
            placeholder="What changed since the last version?"
          />
        </div>
        <div className="mt-4 flex flex-wrap gap-3">
          <Button onClick={handleSubmit} loading={saving}>
            <Upload className="h-4 w-4" />
            Submit version
          </Button>
          {hasSubmissions && (
            <Button variant="subtle" onClick={handleReview} loading={reviewing}>
              <Sparkles className="h-4 w-4" />
              Run AI review on latest
            </Button>
          )}
        </div>
      </div>

      <div className="rounded-xl border border-slate-200 bg-white shadow-sm">
        <div className="border-b border-slate-100 px-5 py-3">
          <h3 className="text-sm font-semibold">Submission history ({submissions.length})</h3>
        </div>
        {submissions.length === 0 ? (
          <p className="px-5 py-8 text-center text-sm text-slate-400">
            No submissions yet. Once a student submits, versions appear here.
          </p>
        ) : (
          <ul className="divide-y divide-slate-50">
            {submissions.map((s) => (
              <li key={s.id} className="px-5 py-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-slate-100">
                      <FileCode className="h-4 w-4 text-slate-500" />
                    </div>
                    <div>
                      <p className="text-sm font-medium text-slate-900">
                        {s.filename} <Badge tone="slate">v{s.version}</Badge>
                      </p>
                      <p className="flex items-center gap-1 text-xs text-slate-400">
                        <Clock className="h-3 w-3" />
                        {formatDateTime(s.created_at)}
                      </p>
                    </div>
                  </div>
                  <Badge tone="neutral">{s.file_type}</Badge>
                </div>
                {s.notes && <p className="mt-2 text-xs text-slate-500">{s.notes}</p>}
                {s.content && (
                  <details className="mt-2">
                    <summary className="cursor-pointer text-xs text-blue-600 hover:text-blue-700">
                      View content
                    </summary>
                    <pre className="mt-2 max-h-64 overflow-auto rounded-lg bg-slate-900 p-3 text-xs text-slate-100 scrollbar-thin">
                      {s.content}
                    </pre>
                  </details>
                )}
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
