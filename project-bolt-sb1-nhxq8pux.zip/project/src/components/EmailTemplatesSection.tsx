import { useState } from 'react';
import { Mail, RotateCcw, ChevronDown, ChevronUp, Eye, Code } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { Textarea } from '@/components/ui/Field';
import { Modal } from '@/components/ui/Modal';
import { toast } from '@/components/ui/Toast';
import {
  TEMPLATE_TYPES,
  PLACEHOLDERS,
  DEFAULT_TEMPLATES,
  SETTINGS_SUBJECT_KEY,
  SETTINGS_BODY_KEY,
  type EmailTemplateType,
} from '@/lib/emailTemplates';

interface EmailTemplatesSectionProps {
  values: Record<string, string>;
  onSave: (values: Record<string, string>) => Promise<void>;
}

export function EmailTemplatesSection({ values, onSave }: EmailTemplatesSectionProps) {
  const [expanded, setExpanded] = useState<EmailTemplateType | null>(null);
  const [drafts, setDrafts] = useState<Record<string, string>>(values);
  const [saving, setSaving] = useState(false);
  const [preview, setPreview] = useState<EmailTemplateType | null>(null);

  function getSubject(type: EmailTemplateType): string {
    return drafts[SETTINGS_SUBJECT_KEY(type)] ?? DEFAULT_TEMPLATES[type].subject;
  }

  function getBody(type: EmailTemplateType): string {
    return drafts[SETTINGS_BODY_KEY(type)] ?? DEFAULT_TEMPLATES[type].body;
  }

  function setSubject(type: EmailTemplateType, val: string) {
    setDrafts((prev) => ({ ...prev, [SETTINGS_SUBJECT_KEY(type)]: val }));
  }

  function setBody(type: EmailTemplateType, val: string) {
    setDrafts((prev) => ({ ...prev, [SETTINGS_BODY_KEY(type)]: val }));
  }

  function resetToDefault(type: EmailTemplateType) {
    const subjectKey = SETTINGS_SUBJECT_KEY(type);
    const bodyKey = SETTINGS_BODY_KEY(type);
    setDrafts((prev) => {
      const next = { ...prev };
      delete next[subjectKey];
      delete next[bodyKey];
      return next;
    });
    toast(`${TEMPLATE_TYPES.find((t) => t.type === type)?.label} reset to default. Save to apply.`);
  }

  function insertPlaceholder(type: EmailTemplateType, placeholder: string) {
    const body = getBody(type);
    const insertion = `{{${placeholder}}}`;
    setBody(type, body + insertion);
  }

  function buildPreview(type: EmailTemplateType): string {
    const sampleCtx: Record<string, string> = {
      student_name: 'Jane Doe',
      project_title: 'Campus Event Booking System',
      student_email: 'jane.doe@example.com',
      status_label: 'Needs Correction',
      score: '72',
      summary: 'The project implements most core features but has a SQL injection risk and missing documentation.',
      what_improved: 'Resolved since last review: Input validation on the booking form; Error handling on date conflicts.',
      what_remains: 'Still outstanding: SQL injection in search; Missing function docstrings.',
      findings: '1. [ERROR] SQL injection in search\\n   Why: User input is concatenated into the query.\\n   Fix: Use parameterized queries.\\n2. [WARNING] Few functions have docstrings\\n   Why: Other developers need to understand each function.\\n   Fix: Add docstrings to each function.',
      next_review: 'Next review: Friday, November 7, 2026, 02:00 PM\\nFormat: Online meeting\\nMeeting link: https://meet.example.com/abc-defg-hij\\nSubmission deadline: Thursday, November 6, 2026, 11:59 PM',
      review_format: 'Online meeting',
      meeting_link: 'https://meet.example.com/abc-defg-hij',
      venue: '',
      submission_deadline: 'Thursday, November 6, 2026, 11:59 PM',
      org_name: 'Internship Program',
      coordinator_name: 'Program Coordinator',
      coordinator_email: 'coordinator@example.com',
      coordinator_phone: '+1 555-0100',
    };
    const body = getBody(type).replace(/\{\{(\w+)\}\}/g, (_m, key: string) => sampleCtx[key] ?? '');
    const subject = getSubject(type).replace(/\{\{(\w+)\}\}/g, (_m, key: string) => sampleCtx[key] ?? '');
    return `Subject: ${subject}\n\n${body}`;
  }

  async function handleSave() {
    setSaving(true);
    try {
      await onSave(drafts);
    } catch (e) {
      toast(e instanceof Error ? e.message : 'Failed to save templates', 'error');
    } finally {
      setSaving(false);
    }
  }

  const hasChanges = JSON.stringify(drafts) !== JSON.stringify(values);

  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
      <div className="flex items-center gap-2">
        <Mail className="h-4 w-4 text-blue-500" />
        <h2 className="text-sm font-semibold">Email templates</h2>
      </div>
      <p className="mt-1 text-xs text-slate-500">
        Customize the wording of automated student emails. Use <code className="rounded bg-slate-100 px-1 py-0.5 text-[11px] text-slate-700">{'{{placeholders}}'}</code> to insert dynamic values. Leave a field empty to use the default.
      </p>

      <div className="mt-4 space-y-2">
        {TEMPLATE_TYPES.map((meta) => {
          const isOpen = expanded === meta.type;
          const isCustom = !!drafts[SETTINGS_BODY_KEY(meta.type)] || !!drafts[SETTINGS_SUBJECT_KEY(meta.type)];
          return (
            <div key={meta.type} className="rounded-lg border border-slate-200 overflow-hidden">
              <button
                onClick={() => setExpanded(isOpen ? null : meta.type)}
                className="flex w-full items-center justify-between px-4 py-3 text-left transition hover:bg-slate-50"
              >
                <div className="flex items-center gap-3">
                  <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-blue-50">
                    <Mail className="h-4 w-4 text-blue-600" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-slate-900">
                      {meta.label}
                      {isCustom && (
                        <span className="ml-2 inline-flex items-center rounded-full bg-blue-50 px-2 py-0.5 text-[10px] font-medium text-blue-700 ring-1 ring-inset ring-blue-200">
                          Customized
                        </span>
                      )}
                    </p>
                    <p className="text-xs text-slate-400">{meta.description}</p>
                  </div>
                </div>
                {isOpen ? <ChevronUp className="h-4 w-4 text-slate-400" /> : <ChevronDown className="h-4 w-4 text-slate-400" />}
              </button>

              {isOpen && (
                <div className="border-t border-slate-100 px-4 py-4 animate-fade-in">
                  <div className="mb-3">
                    <label className="block text-sm font-medium text-slate-700 mb-1.5">Subject line</label>
                    <input
                      type="text"
                      value={getSubject(meta.type)}
                      onChange={(e) => setSubject(meta.type, e.target.value)}
                      placeholder={DEFAULT_TEMPLATES[meta.type].subject}
                      className="w-full rounded-lg border-0 bg-white px-3.5 py-2.5 text-sm text-slate-900 ring-1 ring-inset ring-slate-300 placeholder:text-slate-400 focus:ring-2 focus:ring-inset focus:ring-blue-500 transition shadow-sm"
                    />
                  </div>

                  <div className="mb-3">
                    <label className="block text-sm font-medium text-slate-700 mb-1.5">Email body</label>
                    <Textarea
                      value={getBody(meta.type)}
                      onChange={(e) => setBody(meta.type, e.target.value)}
                      placeholder={DEFAULT_TEMPLATES[meta.type].body}
                      rows={12}
                      className="font-mono text-xs leading-relaxed"
                    />
                  </div>

                  <div className="rounded-lg bg-slate-50 p-3 ring-1 ring-inset ring-slate-200">
                    <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-600 mb-2">
                      <Code className="h-3.5 w-3.5" />
                      Insert placeholder
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {PLACEHOLDERS.filter((p) => !p.reviewOnly || meta.hasReviewFields).map((p) => (
                        <button
                          key={p.key}
                          onClick={() => insertPlaceholder(meta.type, p.key)}
                          title={p.label}
                          className="rounded-md bg-white px-2 py-1 text-[11px] font-mono text-slate-600 ring-1 ring-inset ring-slate-200 transition hover:bg-blue-50 hover:text-blue-700 hover:ring-blue-200"
                        >
                          {`{{${p.key}}}`}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="mt-3 flex items-center gap-2">
                    <Button size="sm" variant="subtle" onClick={() => setPreview(meta.type)}>
                      <Eye className="h-4 w-4" /> Preview with sample data
                    </Button>
                    <Button size="sm" variant="ghost" onClick={() => resetToDefault(meta.type)}>
                      <RotateCcw className="h-4 w-4" /> Reset to default
                    </Button>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      <div className="mt-5 flex items-center justify-between">
        {hasChanges ? (
          <p className="text-xs text-amber-600">Unsaved changes — click Save to apply.</p>
        ) : (
          <p className="text-xs text-slate-400">All templates up to date.</p>
        )}
        <Button onClick={handleSave} loading={saving} disabled={!hasChanges}>
          Save templates
        </Button>
      </div>

      <Modal open={!!preview} onClose={() => setPreview(null)} title="Email preview (sample data)" size="lg">
        {preview && (
          <pre className="max-h-[60vh] overflow-auto whitespace-pre-wrap rounded-lg bg-slate-50 p-4 text-sm text-slate-700 ring-1 ring-inset ring-slate-200 scrollbar-thin">
            {buildPreview(preview)}
          </pre>
        )}
      </Modal>
    </div>
  );
}
