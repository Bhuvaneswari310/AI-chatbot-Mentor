import { useState } from 'react';
import { Plus, Search, Pencil, Trash2, ArrowRight } from 'lucide-react';
import type { Student, SkillLevel, ProjectStatus } from '@/lib/types';
import { statusBadge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Input, Select, Textarea } from '@/components/ui/Field';
import { Modal } from '@/components/ui/Modal';
import { toast } from '@/components/ui/Toast';
import {
  createStudent,
  updateStudent,
  deleteStudent,
  type StudentInput,
} from '@/lib/data';
import { formatDate, isOverdue } from '@/lib/export';

interface StudentsViewProps {
  students: Student[];
  onChanged: () => void;
  onSelectStudent: (id: string) => void;
}

const emptyForm: StudentInput = {
  name: '',
  email: '',
  domain: '',
  project_title: '',
  assigned_mentor: '',
  skill_level: 'intermediate',
  start_date: '',
  expected_completion_date: '',
};

export function StudentsView({ students, onChanged, onSelectStudent }: StudentsViewProps) {
  const [query, setQuery] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Student | null>(null);
  const [form, setForm] = useState<StudentInput>(emptyForm);
  const [saving, setSaving] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const filtered = students.filter((s) => {
    if (!query) return true;
    const q = query.toLowerCase();
    return (
      s.name.toLowerCase().includes(q) ||
      s.project_title.toLowerCase().includes(q) ||
      (s.email ?? '').toLowerCase().includes(q) ||
      (s.domain ?? '').toLowerCase().includes(q)
    );
  });

  function openAdd() {
    setEditing(null);
    setForm(emptyForm);
    setModalOpen(true);
  }

  function openEdit(s: Student) {
    setEditing(s);
    setForm({
      name: s.name,
      email: s.email,
      domain: s.domain ?? '',
      project_title: s.project_title,
      assigned_mentor: s.assigned_mentor ?? '',
      skill_level: s.skill_level,
      start_date: s.start_date ?? '',
      expected_completion_date: s.expected_completion_date ?? '',
    });
    setModalOpen(true);
  }

  async function handleSave() {
    if (!form.name.trim() || !form.email.trim() || !form.project_title.trim()) {
      toast('Name, email, and project title are required.', 'warning');
      return;
    }
    setSaving(true);
    try {
      if (editing) {
        await updateStudent(editing.id, form);
        toast('Student updated.');
      } else {
        await createStudent(form);
        toast('Student added.');
      }
      setModalOpen(false);
      onChanged();
    } catch (e) {
      toast(e instanceof Error ? e.message : 'Failed to save student', 'error');
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete() {
    if (!deleteId) return;
    try {
      await deleteStudent(deleteId);
      toast('Student removed.');
      setDeleteId(null);
      onChanged();
    } catch (e) {
      toast(e instanceof Error ? e.message : 'Failed to delete', 'error');
    }
  }

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Students</h1>
          <p className="mt-1 text-sm text-slate-500">
            Register and manage interns. {students.length} total.
          </p>
        </div>
        <Button onClick={openAdd}>
          <Plus className="h-4 w-4" />
          Add Student
        </Button>
      </div>

      <div className="relative max-w-md">
        <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
        <input
          placeholder="Search students..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          className="w-full rounded-lg border-0 bg-white py-2.5 pl-10 pr-3 text-slate-900 ring-1 ring-inset ring-slate-300 placeholder:text-slate-400 focus:ring-2 focus:ring-inset focus:ring-blue-500 shadow-sm"
        />
      </div>

      {filtered.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-slate-300 bg-white px-6 py-16 text-center">
          <p className="text-sm text-slate-400">
            {students.length === 0 ? 'No students yet. Add your first intern to get started.' : 'No matches found.'}
          </p>
          {students.length === 0 && (
            <Button className="mt-4" onClick={openAdd}>
              <Plus className="h-4 w-4" />
              Add Student
            </Button>
          )}
        </div>
      ) : (
        <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
          {filtered.map((s) => (
            <div
              key={s.id}
              className="group rounded-2xl border border-slate-200 bg-white p-5 shadow-sm transition hover:border-blue-300 hover:shadow-md"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <p className="truncate font-semibold text-slate-900">{s.name}</p>
                  <p className="truncate text-xs text-slate-400">{s.email}</p>
                </div>
                {statusBadge(s.status)}
              </div>
              <p className="mt-3 line-clamp-2 text-sm text-slate-600">{s.project_title}</p>
              <div className="mt-3 flex flex-wrap gap-2 text-xs text-slate-400">
                {s.domain && <span className="rounded-md bg-slate-100 px-2 py-0.5">{s.domain}</span>}
                <span className="rounded-md bg-slate-100 px-2 py-0.5 capitalize">{s.skill_level}</span>
                {s.assigned_mentor && <span className="rounded-md bg-slate-100 px-2 py-0.5">{s.assigned_mentor}</span>}
              </div>
              <div className="mt-2 flex items-center justify-between text-xs">
                <span className={isOverdue(s) ? 'text-rose-600 font-medium' : 'text-slate-400'}>
                  Due {formatDate(s.expected_completion_date)}
                </span>
              </div>
              <div className="mt-4 flex items-center gap-1 border-t border-slate-100 pt-3">
                <button
                  onClick={() => onSelectStudent(s.id)}
                  className="flex flex-1 items-center justify-center gap-1.5 rounded-lg py-2 text-sm font-medium text-blue-600 transition hover:bg-blue-50"
                >
                  Open <ArrowRight className="h-4 w-4" />
                </button>
                <button
                  onClick={() => openEdit(s)}
                  className="rounded-lg p-2 text-slate-400 transition hover:bg-slate-100 hover:text-slate-700"
                  aria-label="Edit"
                >
                  <Pencil className="h-4 w-4" />
                </button>
                <button
                  onClick={() => setDeleteId(s.id)}
                  className="rounded-lg p-2 text-slate-400 transition hover:bg-rose-50 hover:text-rose-600"
                  aria-label="Delete"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editing ? 'Edit Student' : 'Add Student'}
        size="lg"
      >
        <div className="grid gap-4 sm:grid-cols-2">
          <Input
            label="Full name"
            value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
            placeholder="Jane Doe"
          />
          <Input
            label="Email"
            type="email"
            value={form.email}
            onChange={(e) => setForm({ ...form, email: e.target.value })}
            placeholder="jane@example.com"
          />
          <Input
            label="Project title"
            value={form.project_title}
            onChange={(e) => setForm({ ...form, project_title: e.target.value })}
            placeholder="Inventory management web app"
          />
          <Input
            label="Internship domain"
            value={form.domain}
            onChange={(e) => setForm({ ...form, domain: e.target.value })}
            placeholder="Web Development"
          />
          <Input
            label="Assigned mentor"
            value={form.assigned_mentor}
            onChange={(e) => setForm({ ...form, assigned_mentor: e.target.value })}
            placeholder="Alex Chen"
          />
          <Select
            label="Skill level"
            value={form.skill_level}
            onChange={(e) => setForm({ ...form, skill_level: e.target.value as SkillLevel })}
          >
            <option value="beginner">Beginner</option>
            <option value="intermediate">Intermediate</option>
            <option value="advanced">Advanced</option>
          </Select>
          <Input
            label="Start date"
            type="date"
            value={form.start_date ?? ''}
            onChange={(e) => setForm({ ...form, start_date: e.target.value })}
          />
          <Input
            label="Expected completion"
            type="date"
            value={form.expected_completion_date ?? ''}
            onChange={(e) => setForm({ ...form, expected_completion_date: e.target.value })}
          />
        </div>
        <div className="mt-6 flex justify-end gap-3">
          <Button variant="secondary" onClick={() => setModalOpen(false)}>
            Cancel
          </Button>
          <Button onClick={handleSave} loading={saving}>
            {editing ? 'Save changes' : 'Add student'}
          </Button>
        </div>
      </Modal>

      <Modal
        open={!!deleteId}
        onClose={() => setDeleteId(null)}
        title="Remove student?"
        size="sm"
      >
        <p className="text-sm text-slate-600">
          This will permanently delete the student and all their submissions, reviews, chat history, and schedules. This cannot be undone.
        </p>
        <div className="mt-6 flex justify-end gap-3">
          <Button variant="secondary" onClick={() => setDeleteId(null)}>
            Cancel
          </Button>
          <Button variant="danger" onClick={handleDelete}>
            Delete
          </Button>
        </div>
      </Modal>
    </div>
  );
}
