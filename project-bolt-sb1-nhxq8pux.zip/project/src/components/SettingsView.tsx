import { useEffect, useState } from 'react';
import { Save, Settings as Cog, Mail } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Field';
import { toast } from '@/components/ui/Toast';
import { fetchSettings, updateSettings } from '@/lib/data';
import { EmailTemplatesSection } from '@/components/EmailTemplatesSection';

export function SettingsView() {
  const [values, setValues] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetchSettings()
      .then(setValues)
      .catch((e) => toast(e instanceof Error ? e.message : 'Failed to load settings', 'error'))
      .finally(() => setLoading(false));
  }, []);

  async function handleSave() {
    setSaving(true);
    try {
      await updateSettings(values);
      toast('Settings saved.');
    } catch (e) {
      toast(e instanceof Error ? e.message : 'Failed to save', 'error');
    } finally {
      setSaving(false);
    }
  }

  if (loading) {
    return <div className="animate-pulse text-sm text-slate-400">Loading settings...</div>;
  }

  return (
    <div className="max-w-2xl space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Settings</h1>
        <p className="mt-1 text-sm text-slate-500">
          These details appear in automated email notifications sent to students.
        </p>
      </div>

      <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
        <div className="flex items-center gap-2">
          <Cog className="h-4 w-4 text-slate-400" />
          <h2 className="text-sm font-semibold">Organization & coordinator</h2>
        </div>
        <div className="mt-4 space-y-4">
          <Input
            label="Organization name"
            value={values.org_name ?? ''}
            onChange={(e) => setValues({ ...values, org_name: e.target.value })}
          />
          <Input
            label="Coordinator name"
            value={values.coordinator_name ?? ''}
            onChange={(e) => setValues({ ...values, coordinator_name: e.target.value })}
          />
          <Input
            label="Coordinator email"
            type="email"
            value={values.coordinator_email ?? ''}
            onChange={(e) => setValues({ ...values, coordinator_email: e.target.value })}
          />
          <Input
            label="Coordinator phone"
            value={values.coordinator_phone ?? ''}
            onChange={(e) => setValues({ ...values, coordinator_phone: e.target.value })}
          />
        </div>
        <div className="mt-5">
          <Button onClick={handleSave} loading={saving}>
            <Save className="h-4 w-4" />
            Save settings
          </Button>
        </div>
      </div>

      <EmailTemplatesSection values={values} onSave={async (templateValues) => {
        const merged = { ...values, ...templateValues };
        setValues(merged);
        await updateSettings(templateValues);
        toast('Email templates saved.');
      }} />

      <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
        <div className="flex items-center gap-2">
          <Mail className="h-4 w-4 text-slate-400" />
          <h2 className="text-sm font-semibold">Integrations</h2>
        </div>
        <div className="mt-4 space-y-3">
          <Integration
            name="AI review & chatbot (OpenAI)"
            status="test-mode"
            description="Running in test mode with built-in static analysis. To enable LLM-powered reviews and chat, add an OPENAI_API_KEY secret to your Supabase edge functions. The app automatically uses the LLM when a key is present."
          />
          <Integration
            name="Email delivery (SMTP)"
            status="manual"
            description="SMTP is not configured. Emails are generated and stored in the Emails tab per student — copy, download, or mark as sent manually. Connect a transactional email service to enable automatic delivery."
          />
          <Integration
            name="Google Calendar / Meet"
            status="manual"
            description="Calendar API integration is not connected. Coordinators can enter an existing Google Meet or Zoom link manually when scheduling a review."
          />
        </div>
      </div>
    </div>
  );
}

function Integration({ name, status, description }: { name: string; status: 'test-mode' | 'manual' | 'active'; description: string }) {
  const tone = status === 'active' ? 'green' : status === 'test-mode' ? 'amber' : 'neutral';
  const label = status === 'active' ? 'Active' : status === 'test-mode' ? 'Test mode' : 'Manual';
  return (
    <div className="rounded-lg border border-slate-200 p-4">
      <div className="flex items-center justify-between">
        <p className="text-sm font-medium text-slate-900">{name}</p>
        <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ring-1 ring-inset ${
          tone === 'green' ? 'bg-emerald-50 text-emerald-700 ring-emerald-200' :
          tone === 'amber' ? 'bg-amber-50 text-amber-700 ring-amber-200' :
          'bg-slate-100 text-slate-600 ring-slate-200'
        }`}>
          {label}
        </span>
      </div>
      <p className="mt-1.5 text-xs text-slate-500">{description}</p>
    </div>
  );
}
