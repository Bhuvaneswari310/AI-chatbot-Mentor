import { type ReactNode } from 'react';

export function Badge({
  children,
  tone = 'neutral',
}: {
  children: ReactNode;
  tone?: 'neutral' | 'blue' | 'amber' | 'green' | 'red' | 'slate';
}) {
  const tones: Record<string, string> = {
    neutral: 'bg-slate-100 text-slate-700 ring-slate-200',
    blue: 'bg-blue-50 text-blue-700 ring-blue-200',
    amber: 'bg-amber-50 text-amber-700 ring-amber-200',
    green: 'bg-emerald-50 text-emerald-700 ring-emerald-200',
    red: 'bg-rose-50 text-rose-700 ring-rose-200',
    slate: 'bg-slate-800 text-slate-100 ring-slate-700',
  };
  return (
    <span
      className={`inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-medium ring-1 ring-inset ${tones[tone]}`}
    >
      {children}
    </span>
  );
}

export function statusBadge(status: string) {
  if (status === 'approved') return <Badge tone="green">Approved</Badge>;
  if (status === 'ready_for_review') return <Badge tone="blue">Ready for Review</Badge>;
  return <Badge tone="amber">Needs Correction</Badge>;
}

export function severityBadge(sev: string) {
  if (sev === 'error') return <Badge tone="red">Error</Badge>;
  if (sev === 'warning') return <Badge tone="amber">Warning</Badge>;
  if (sev === 'passed') return <Badge tone="green">Passed</Badge>;
  return <Badge tone="neutral">Improvement</Badge>;
}
