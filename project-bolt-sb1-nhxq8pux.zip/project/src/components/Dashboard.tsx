import { useMemo, useState } from 'react';
import {
  Users,
  FileSearch,
  AlertTriangle,
  CalendarClock,
  CheckCircle2,
  Clock,
  TrendingUp,
  ArrowRight,
  Download,
} from 'lucide-react';
import type { Student, Schedule } from '@/lib/types';
import { statusBadge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Input, Select } from '@/components/ui/Field';
import { formatDate, formatDateTime, isOverdue, downloadCSV } from '@/lib/export';

interface DashboardProps {
  students: Student[];
  schedules: Schedule[];
  onSelectStudent: (id: string) => void;
  onGoToStudents: () => void;
}

interface StatCardProps {
  label: string;
  value: number | string;
  icon: typeof Users;
  tone: string;
  sub?: string;
}

function StatCard({ label, value, icon: Icon, tone, sub }: StatCardProps) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm transition hover:shadow-md">
      <div className="flex items-center justify-between">
        <div className={`flex h-10 w-10 items-center justify-center rounded-xl ${tone}`}>
          <Icon className="h-5 w-5" />
        </div>
      </div>
      <p className="mt-4 text-3xl font-bold tracking-tight text-slate-900">{value}</p>
      <p className="mt-0.5 text-sm font-medium text-slate-600">{label}</p>
      {sub && <p className="mt-1 text-xs text-slate-400">{sub}</p>}
    </div>
  );
}

export function Dashboard({ students, schedules, onSelectStudent, onGoToStudents }: DashboardProps) {
  const [query, setQuery] = useState('');
  const [domainFilter, setDomainFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');

  const stats = useMemo(() => {
    const needs = students.filter((s) => s.status === 'needs_correction').length;
    const ready = students.filter((s) => s.status === 'ready_for_review').length;
    const approved = students.filter((s) => s.status === 'approved').length;
    const overdue = students.filter(isOverdue).length;
    const upcoming = schedules.filter(
      (s) => new Date(s.review_at) > new Date(),
    ).length;
    return { total: students.length, needs, ready, approved, overdue, upcoming };
  }, [students, schedules]);

  const domains = useMemo(
    () => [...new Set(students.map((s) => s.domain).filter(Boolean))] as string[],
    [students],
  );

  const filtered = useMemo(() => {
    return students.filter((s) => {
      if (query) {
        const q = query.toLowerCase();
        if (
          !s.name.toLowerCase().includes(q) &&
          !s.project_title.toLowerCase().includes(q) &&
          !(s.email ?? '').toLowerCase().includes(q)
        )
          return false;
      }
      if (domainFilter !== 'all' && s.domain !== domainFilter) return false;
      if (statusFilter !== 'all' && s.status !== statusFilter) return false;
      return true;
    });
  }, [students, query, domainFilter, statusFilter]);

  const upcomingReviews = useMemo(() => {
    return schedules
      .filter((s) => new Date(s.review_at) > new Date())
      .sort((a, b) => new Date(a.review_at).getTime() - new Date(b.review_at).getTime())
      .slice(0, 5)
      .map((s) => ({
        ...s,
        student: students.find((st) => st.id === s.student_id),
      }))
      .filter((s) => s.student);
  }, [schedules, students]);

  function handleExport() {
    downloadCSV(
      'student_progress_report.csv',
      filtered.map((s) => ({
        Name: s.name,
        Email: s.email,
        Domain: s.domain ?? '',
        Project: s.project_title,
        Mentor: s.assigned_mentor ?? '',
        Status: s.status.replace(/_/g, ' '),
        'Start Date': formatDate(s.start_date),
        'Expected Completion': formatDate(s.expected_completion_date),
        Overdue: isOverdue(s) ? 'Yes' : 'No',
      })),
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Dashboard</h1>
          <p className="mt-1 text-sm text-slate-500">
            Overview of all interns, reviews, and upcoming activities.
          </p>
        </div>
        <Button variant="secondary" size="sm" onClick={handleExport}>
          <Download className="h-4 w-4" />
          Export CSV
        </Button>
      </div>

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-3 xl:grid-cols-6">
        <StatCard label="Total Students" value={stats.total} icon={Users} tone="bg-blue-50 text-blue-600" />
        <StatCard label="Needs Correction" value={stats.needs} icon={AlertTriangle} tone="bg-amber-50 text-amber-600" />
        <StatCard label="Ready for Review" value={stats.ready} icon={FileSearch} tone="bg-blue-50 text-blue-600" />
        <StatCard label="Completed" value={stats.approved} icon={CheckCircle2} tone="bg-emerald-50 text-emerald-600" />
        <StatCard label="Upcoming Reviews" value={stats.upcoming} icon={CalendarClock} tone="bg-indigo-50 text-indigo-600" />
        <StatCard label="Overdue" value={stats.overdue} icon={Clock} tone="bg-rose-50 text-rose-600" />
      </div>

      {/* Upcoming reviews */}
      <div className="rounded-2xl border border-slate-200 bg-white shadow-sm">
        <div className="flex items-center justify-between border-b border-slate-100 px-5 py-4">
          <h2 className="text-base font-semibold">Upcoming Reviews</h2>
          <TrendingUp className="h-4 w-4 text-slate-400" />
        </div>
        {upcomingReviews.length === 0 ? (
          <p className="px-5 py-8 text-center text-sm text-slate-400">
            No upcoming reviews scheduled.
          </p>
        ) : (
          <ul className="divide-y divide-slate-100">
            {upcomingReviews.map((r) => (
              <li
                key={r.id}
                className="flex items-center justify-between px-5 py-3 transition hover:bg-slate-50 cursor-pointer"
                onClick={() => onSelectStudent(r.student_id)}
              >
                <div className="min-w-0">
                  <p className="truncate text-sm font-medium text-slate-900">{r.student!.name}</p>
                  <p className="truncate text-xs text-slate-500">{r.student!.project_title}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm text-slate-700">{formatDateTime(r.review_at)}</p>
                  <p className="text-xs text-slate-400">
                    {r.mode === 'online' ? 'Online' : r.venue ?? 'In person'}
                  </p>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>

      {/* Student table with filters */}
      <div className="rounded-2xl border border-slate-200 bg-white shadow-sm">
        <div className="border-b border-slate-100 px-5 py-4">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <h2 className="text-base font-semibold">Students</h2>
            <div className="flex flex-col gap-2 sm:flex-row">
              <Input
                placeholder="Search name, project, email..."
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                className="sm:w-56"
              />
              <Select value={domainFilter} onChange={(e) => setDomainFilter(e.target.value)} className="sm:w-40">
                <option value="all">All domains</option>
                {domains.map((d) => (
                  <option key={d} value={d}>{d}</option>
                ))}
              </Select>
              <Select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className="sm:w-44">
                <option value="all">All statuses</option>
                <option value="needs_correction">Needs Correction</option>
                <option value="ready_for_review">Ready for Review</option>
                <option value="approved">Approved</option>
              </Select>
            </div>
          </div>
        </div>
        {filtered.length === 0 ? (
          <div className="px-5 py-12 text-center">
            <p className="text-sm text-slate-400">No students match your filters.</p>
            <Button variant="subtle" size="sm" className="mt-3" onClick={onGoToStudents}>
              Go to Students <ArrowRight className="h-4 w-4" />
            </Button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-100 text-left text-xs font-medium uppercase tracking-wide text-slate-400">
                  <th className="px-5 py-3">Student</th>
                  <th className="px-5 py-3">Project</th>
                  <th className="px-5 py-3">Domain</th>
                  <th className="px-5 py-3">Status</th>
                  <th className="px-5 py-3">Due</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {filtered.map((s) => (
                  <tr
                    key={s.id}
                    className="cursor-pointer transition hover:bg-slate-50"
                    onClick={() => onSelectStudent(s.id)}
                  >
                    <td className="px-5 py-3">
                      <p className="font-medium text-slate-900">{s.name}</p>
                      <p className="text-xs text-slate-400">{s.email}</p>
                    </td>
                    <td className="px-5 py-3 text-slate-600">{s.project_title}</td>
                    <td className="px-5 py-3 text-slate-600">{s.domain ?? '—'}</td>
                    <td className="px-5 py-3">{statusBadge(s.status)}</td>
                    <td className="px-5 py-3">
                      <span className={isOverdue(s) ? 'text-rose-600 font-medium' : 'text-slate-600'}>
                        {formatDate(s.expected_completion_date)}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
