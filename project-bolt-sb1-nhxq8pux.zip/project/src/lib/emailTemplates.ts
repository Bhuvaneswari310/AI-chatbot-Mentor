export type EmailTemplateType = 'review_update' | 'reminder' | 'overdue' | 'resubmission' | 'approval';

export interface TemplateMeta {
  type: EmailTemplateType;
  label: string;
  description: string;
  hasReviewFields: boolean;
}

export const TEMPLATE_TYPES: TemplateMeta[] = [
  {
    type: 'review_update',
    label: 'Review Update',
    description: 'Sent automatically after each AI review with the score, findings, and next review details.',
    hasReviewFields: true,
  },
  {
    type: 'reminder',
    label: 'Review Reminder',
    description: 'Sent as a friendly reminder about an upcoming review.',
    hasReviewFields: false,
  },
  {
    type: 'overdue',
    label: 'Overdue Notice',
    description: 'Sent when a student has not completed corrections in time.',
    hasReviewFields: false,
  },
  {
    type: 'resubmission',
    label: 'Resubmission Received',
    description: 'Sent when a student submits an updated project version.',
    hasReviewFields: false,
  },
  {
    type: 'approval',
    label: 'Project Approved',
    description: 'Sent when the project is approved and completed.',
    hasReviewFields: false,
  },
];

export const PLACEHOLDERS: { key: string; label: string; reviewOnly: boolean }[] = [
  { key: 'student_name', label: 'Student full name', reviewOnly: false },
  { key: 'project_title', label: 'Project title', reviewOnly: false },
  { key: 'student_email', label: 'Student email address', reviewOnly: false },
  { key: 'status_label', label: 'Human-readable review status', reviewOnly: true },
  { key: 'score', label: 'Review score out of 100', reviewOnly: true },
  { key: 'summary', label: 'AI-generated review summary', reviewOnly: true },
  { key: 'what_improved', label: 'What improved since last review', reviewOnly: true },
  { key: 'what_remains', label: 'What remains to fix', reviewOnly: true },
  { key: 'findings', label: 'Numbered list of findings and fixes', reviewOnly: true },
  { key: 'next_review', label: 'Next review date, time, format, and link', reviewOnly: false },
  { key: 'review_format', label: 'Online meeting or In person', reviewOnly: false },
  { key: 'meeting_link', label: 'Meeting link (online reviews only)', reviewOnly: false },
  { key: 'venue', label: 'Venue (in-person reviews only)', reviewOnly: false },
  { key: 'submission_deadline', label: 'Resubmission deadline', reviewOnly: false },
  { key: 'org_name', label: 'Organization name (from settings)', reviewOnly: false },
  { key: 'coordinator_name', label: 'Coordinator name (from settings)', reviewOnly: false },
  { key: 'coordinator_email', label: 'Coordinator email (from settings)', reviewOnly: false },
  { key: 'coordinator_phone', label: 'Coordinator phone (from settings)', reviewOnly: false },
];

export const DEFAULT_TEMPLATES: Record<EmailTemplateType, { subject: string; body: string }> = {
  review_update: {
    subject: 'Internship Project Review Update – {{project_title}} – {{student_name}}',
    body: `Dear {{student_name}},

Here is the latest review update for your internship project "{{project_title}}".

Current status: {{status_label}}
Review score: {{score}}/100

Summary: {{summary}}

{{what_improved}}
{{what_remains}}

Findings and required actions:
{{findings}}

{{next_review}}

Please address the items above and resubmit your updated project before the deadline.

Wishing you the best,
{{coordinator_name}}
{{org_name}}
{{coordinator_email}}
{{coordinator_phone}}`,
  },
  reminder: {
    subject: 'Upcoming Review Reminder – {{project_title}} – {{student_name}}',
    body: `Dear {{student_name}},

This is a friendly reminder about your upcoming project review for "{{project_title}}".

{{next_review}}

If you have any questions, just reply to this thread or reach out using the contact details below.

Wishing you the best,
{{coordinator_name}}
{{org_name}}
{{coordinator_email}}
{{coordinator_phone}}`,
  },
  overdue: {
    subject: 'Overdue Correction – {{project_title}} – {{student_name}}',
    body: `Dear {{student_name}},

Our records show that corrections for your project "{{project_title}}" are now overdue. Please prioritize completing them so we can schedule your next review.

{{next_review}}

If you have any questions, just reply to this thread or reach out using the contact details below.

Wishing you the best,
{{coordinator_name}}
{{org_name}}
{{coordinator_email}}
{{coordinator_phone}}`,
  },
  resubmission: {
    subject: 'Resubmission Received – {{project_title}} – {{student_name}}',
    body: `Dear {{student_name}},

We've received your updated submission for "{{project_title}}". A new review will be generated shortly, and you'll receive the feedback by email.

{{next_review}}

If you have any questions, just reply to this thread or reach out using the contact details below.

Wishing you the best,
{{coordinator_name}}
{{org_name}}
{{coordinator_email}}
{{coordinator_phone}}`,
  },
  approval: {
    subject: 'Project Approved – {{project_title}} – {{student_name}}',
    body: `Dear {{student_name}},

Congratulations! Your internship project "{{project_title}}" has been reviewed and approved. Great work reaching this milestone.

{{next_review}}

If you have any questions, just reply to this thread or reach out using the contact details below.

Wishing you the best,
{{coordinator_name}}
{{org_name}}
{{coordinator_email}}
{{coordinator_phone}}`,
  },
};

export const SETTINGS_SUBJECT_KEY = (type: EmailTemplateType) => `template_${type}_subject`;
export const SETTINGS_BODY_KEY = (type: EmailTemplateType) => `template_${type}`;
