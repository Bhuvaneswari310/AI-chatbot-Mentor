import { createClient } from '@supabase/supabase-js';

const url = import.meta.env.VITE_SUPABASE_URL;
const anonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!url || !anonKey) {
  throw new Error('Supabase env vars missing (VITE_SUPABASE_URL / VITE_SUPABASE_ANON_KEY)');
}

export const supabase = createClient(url, anonKey, {
  auth: { persistSession: false },
});

export const SUPABASE_URL = url;
export const EDGE_BASE = `${url}/functions/v1`;

export async function callEdge<T>(
  name: string,
  body: unknown,
  method: 'POST' | 'GET' = 'POST',
): Promise<T> {
  const res = await fetch(`${EDGE_BASE}/${name}`, {
    method,
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${anonKey}`,
    },
    body: method === 'POST' ? JSON.stringify(body) : undefined,
  });
  const text = await res.text();
  let json: unknown = null;
  try {
    json = text ? JSON.parse(text) : null;
  } catch {
    throw new Error(`Edge function ${name} returned non-JSON (status ${res.status})`);
  }
  if (!res.ok) {
    const msg =
      json && typeof json === 'object' && 'error' in json
        ? String((json as Record<string, unknown>).error)
        : `Request failed (${res.status})`;
    throw new Error(msg);
  }
  return json as T;
}
