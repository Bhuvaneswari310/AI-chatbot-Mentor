import { supabase } from './supabase';
import { callEdge } from './supabase';
import type {
  Student,
  Requirement,
  Submission,
  Review,
  ReviewItem,
  ChatMessage,
  Schedule,
  EmailLog,
  Setting,
} from './types';

export type StudentInput = Omit<
  Student,
  'id' | 'created_at' | 'updated_at' | 'status' | 'domain' | 'assigned_mentor' | 'start_date' | 'expected_completion_date'
> & {
  status?: Student['status'];
  domain: string;
  assigned_mentor: string;
  start_date: string;
  expected_completion_date: string;
};

export async function fetchStudents(): Promise<Student[]> {
  const { data, error } = await supabase
    .from('students')
    .select('*')
    .order('created_at', { ascending: false });
  if (error) throw error;
  return data as Student[];
}

export async function createStudent(input: StudentInput): Promise<Student> {
  const { data, error } = await supabase.from('students').insert(input).select().maybeSingle();
  if (error) throw error;
  return data as Student;
}

export async function updateStudent(id: string, input: Partial<StudentInput>): Promise<Student> {
  const { data, error } = await supabase
    .from('students')
    .update({ ...input, updated_at: new Date().toISOString() })
    .eq('id', id)
    .select()
    .maybeSingle();
  if (error) throw error;
  return data as Student;
}

export async function deleteStudent(id: string): Promise<void> {
  const { error } = await supabase.from('students').delete().eq('id', id);
  if (error) throw error;
}

export async function fetchRequirements(studentId: string): Promise<Requirement[]> {
  const { data, error } = await supabase
    .from('requirements')
    .select('*')
    .eq('student_id', studentId)
    .order('created_at', { ascending: true });
  if (error) throw error;
  return data as Requirement[];
}

export async function addRequirement(studentId: string, description: string, isMandatory: boolean): Promise<void> {
  const { error } = await supabase
    .from('requirements')
    .insert({ student_id: studentId, description, is_mandatory: isMandatory });
  if (error) throw error;
}

export async function deleteRequirement(id: string): Promise<void> {
  const { error } = await supabase.from('requirements').delete().eq('id', id);
  if (error) throw error;
}

export async function fetchSubmissions(studentId: string): Promise<Submission[]> {
  const { data, error } = await supabase
    .from('submissions')
    .select('*')
    .eq('student_id', studentId)
    .order('version', { ascending: false });
  if (error) throw error;
  return data as Submission[];
}

export async function addSubmission(
  studentId: string,
  filename: string,
  fileType: string,
  content: string,
  notes: string,
): Promise<Submission> {
  const { data: existing } = await supabase
    .from('submissions')
    .select('version')
    .eq('student_id', studentId)
    .order('version', { ascending: false })
    .limit(1)
    .maybeSingle();
  const nextVersion = (existing?.version ?? 0) + 1;

  const { data, error } = await supabase
    .from('submissions')
    .insert({
      student_id: studentId,
      version: nextVersion,
      filename,
      file_type: fileType,
      content,
      notes,
    })
    .select()
    .maybeSingle();
  if (error) throw error;
  return data as Submission;
}

export async function fetchReviews(studentId: string): Promise<Review[]> {
  const { data, error } = await supabase
    .from('reviews')
    .select('*')
    .eq('student_id', studentId)
    .order('review_number', { ascending: false });
  if (error) throw error;
  return data as Review[];
}

export async function fetchReviewItems(reviewId: string): Promise<ReviewItem[]> {
  const { data, error } = await supabase
    .from('review_items')
    .select('*')
    .eq('review_id', reviewId)
    .order('severity', { ascending: true });
  if (error) throw error;
  return data as ReviewItem[];
}

export async function toggleReviewItemResolved(itemId: string, resolved: boolean): Promise<void> {
  const { error } = await supabase.from('review_items').update({ resolved }).eq('id', itemId);
  if (error) throw error;
}

export async function approveStudent(studentId: string): Promise<void> {
  const { error } = await supabase
    .from('students')
    .update({ status: 'approved', updated_at: new Date().toISOString() })
    .eq('id', studentId);
  if (error) throw error;
}

export async function fetchChat(studentId: string): Promise<ChatMessage[]> {
  const { data, error } = await supabase
    .from('chat_messages')
    .select('*')
    .eq('student_id', studentId)
    .order('created_at', { ascending: true });
  if (error) throw error;
  return data as ChatMessage[];
}

export async function fetchAllSchedules(): Promise<Schedule[]> {
  const { data, error } = await supabase
    .from('schedules')
    .select('*')
    .order('review_at', { ascending: false });
  if (error) throw error;
  return data as Schedule[];
}

export async function fetchSchedules(studentId: string): Promise<Schedule[]> {
  const { data, error } = await supabase
    .from('schedules')
    .select('*')
    .eq('student_id', studentId)
    .order('review_at', { ascending: false });
  if (error) throw error;
  return data as Schedule[];
}

export async function upsertSchedule(
  studentId: string,
  input: {
    review_at: string;
    mode: 'online' | 'in_person';
    venue: string | null;
    meet_url: string | null;
    submission_deadline: string | null;
    reminder_interval_days: number;
  },
): Promise<void> {
  const { error } = await supabase.from('schedules').insert({
    student_id: studentId,
    ...input,
  });
  if (error) throw error;
}

export async function deleteSchedule(id: string): Promise<void> {
  const { error } = await supabase.from('schedules').delete().eq('id', id);
  if (error) throw error;
}

export async function fetchEmails(studentId: string): Promise<EmailLog[]> {
  const { data, error } = await supabase
    .from('email_log')
    .select('*')
    .eq('student_id', studentId)
    .order('created_at', { ascending: false });
  if (error) throw error;
  return data as EmailLog[];
}

export async function markEmailSent(id: string): Promise<void> {
  const { error } = await supabase.from('email_log').update({ sent: true }).eq('id', id);
  if (error) throw error;
}

export async function fetchSettings(): Promise<Record<string, string>> {
  const { data, error } = await supabase.from('settings').select('key, value');
  if (error) throw error;
  return Object.fromEntries((data ?? []).map((s) => [s.key, s.value]));
}

export async function updateSettings(values: Record<string, string>): Promise<void> {
  const rows = Object.entries(values).map(([key, value]) => ({
    key,
    value,
    updated_at: new Date().toISOString(),
  }));
  for (const row of rows) {
    const { error } = await supabase.from('settings').upsert(row, { onConflict: 'key' });
    if (error) throw error;
  }
}

interface ReviewResponse {
  review: Review;
  items: ReviewItem[];
  email_subject: string;
  email_body: string;
  email_id: string | null;
  email_sent: boolean;
  email_error: string | null;
  test_mode: boolean;
}

export async function runReview(studentId: string): Promise<ReviewResponse> {
  return callEdge<ReviewResponse>('ai-review', { student_id: studentId });
}

interface ChatResponse {
  message: string;
  model: string;
  test_mode: boolean;
}

export async function sendChat(studentId: string, message: string): Promise<ChatResponse> {
  return callEdge<ChatResponse>('ai-mentor', { student_id: studentId, message });
}

interface EmailResponse {
  subject: string;
  body: string;
  email_id: string | null;
}

export async function renderEmail(
  studentId: string,
  type: 'review_update' | 'reminder' | 'overdue' | 'resubmission' | 'approval',
  reviewId?: string,
): Promise<EmailResponse> {
  return callEdge<EmailResponse>('render-email', { student_id: studentId, type, review_id: reviewId });
}

interface SendEmailResponse {
  ok: boolean;
  configured?: boolean;
  messageId?: string;
  sent_to?: string;
  email_id?: string;
  error?: string;
  already_sent?: boolean;
}

export async function sendEmail(emailId: string): Promise<SendEmailResponse> {
  return callEdge<SendEmailResponse>('send-email', { action: 'send', email_id: emailId });
}

export async function sendTestEmail(testTo?: string): Promise<SendEmailResponse> {
  return callEdge<SendEmailResponse>('send-email', { action: 'test', test_to: testTo });
}

interface SmtpStatus {
  configured: boolean;
  host: string | null;
  port: string | null;
  from: string | null;
}

export async function getSmtpStatus(): Promise<SmtpStatus> {
  return callEdge<SmtpStatus>('send-email', { action: 'status' });
}
