export type SkillLevel = 'beginner' | 'intermediate' | 'advanced';
export type ProjectStatus = 'needs_correction' | 'ready_for_review' | 'approved';
export type ReviewState = 'needs_correction' | 'ready_for_review' | 'approved';
export type ItemSeverity = 'error' | 'warning' | 'improvement' | 'passed';
export type EmailType =
  | 'review_update'
  | 'reminder'
  | 'overdue'
  | 'resubmission'
  | 'approval';

export interface Student {
  id: string;
  name: string;
  email: string;
  domain: string | null;
  project_title: string;
  assigned_mentor: string | null;
  skill_level: SkillLevel;
  start_date: string | null;
  expected_completion_date: string | null;
  status: ProjectStatus;
  created_at: string;
  updated_at: string;
}

export interface Requirement {
  id: string;
  student_id: string;
  description: string;
  is_mandatory: boolean;
  created_at: string;
}

export interface Submission {
  id: string;
  student_id: string;
  version: number;
  filename: string;
  file_type: string;
  content: string | null;
  notes: string | null;
  created_at: string;
}

export interface ReviewItem {
  id: string;
  review_id: string;
  severity: ItemSeverity;
  category: string | null;
  title: string;
  explanation: string | null;
  fix: string | null;
  resolved: boolean;
}

export interface Review {
  id: string;
  student_id: string;
  submission_id: string;
  review_number: number;
  score: number;
  state: ReviewState;
  summary: string | null;
  what_improved: string | null;
  what_remains: string | null;
  ai_model: string | null;
  created_at: string;
  review_items?: ReviewItem[];
}

export interface ChatMessage {
  id: string;
  student_id: string;
  role: 'student' | 'mentor';
  content: string;
  created_at: string;
}

export interface Schedule {
  id: string;
  student_id: string;
  review_at: string;
  mode: 'online' | 'in_person';
  venue: string | null;
  meet_url: string | null;
  submission_deadline: string | null;
  reminder_interval_days: number;
  created_at: string;
  updated_at: string;
}

export interface EmailLog {
  id: string;
  student_id: string;
  review_id: string | null;
  subject: string;
  body: string;
  email_type: EmailType;
  sent: boolean;
  created_at: string;
}

export interface Setting {
  key: string;
  value: string;
  updated_at: string;
}

export interface ReviewResult {
  review: Review;
  items: ReviewItem[];
  email_subject: string;
  email_body: string;
}

export interface ChatResult {
  message: string;
}
