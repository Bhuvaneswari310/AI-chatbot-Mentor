import { useCallback, useEffect, useState } from 'react';
import { AppShell, type View } from '@/components/AppShell';
import { Dashboard } from '@/components/Dashboard';
import { StudentsView } from '@/components/StudentsView';
import { SettingsView } from '@/components/SettingsView';
import { StudentDetail } from '@/components/detail/StudentDetail';
import { Toaster } from '@/components/ui/Toast';
import { fetchStudents, fetchAllSchedules } from '@/lib/data';
import type { Student, Schedule } from '@/lib/types';

export default function App() {
  const [view, setView] = useState<View>('dashboard');
  const [students, setStudents] = useState<Student[]>([]);
  const [schedules, setSchedules] = useState<Schedule[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    try {
      const [s, sch] = await Promise.all([fetchStudents(), fetchAllSchedules()]);
      setStudents(s);
      setSchedules(sch);
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to load data');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  const selected = selectedId ? students.find((s) => s.id === selectedId) ?? null : null;

  function handleNavigate(v: View) {
    setSelectedId(null);
    setView(v);
  }

  function handleSelectStudent(id: string) {
    setSelectedId(id);
    setView('students');
  }

  return (
    <>
      <AppShell view={view} onNavigate={handleNavigate}>
        {loading ? (
          <div className="flex items-center justify-center py-20">
            <div className="flex flex-col items-center gap-3">
              <svg className="h-8 w-8 animate-spin text-blue-500" viewBox="0 0 24 24" fill="none">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z" />
              </svg>
              <p className="text-sm text-slate-400">Loading...</p>
            </div>
          </div>
        ) : error ? (
          <div className="rounded-2xl border border-rose-200 bg-rose-50 p-8 text-center">
            <p className="text-sm font-medium text-rose-800">Something went wrong</p>
            <p className="mt-1 text-sm text-rose-600">{error}</p>
            <button onClick={refresh} className="mt-4 rounded-lg bg-rose-600 px-4 py-2 text-sm font-medium text-white hover:bg-rose-700">
              Try again
            </button>
          </div>
        ) : selected ? (
          <StudentDetail
            student={selected}
            allSchedules={schedules}
            onBack={() => setSelectedId(null)}
            onChanged={refresh}
          />
        ) : view === 'dashboard' ? (
          <Dashboard
            students={students}
            schedules={schedules}
            onSelectStudent={handleSelectStudent}
            onGoToStudents={() => setView('students')}
          />
        ) : view === 'students' ? (
          <StudentsView students={students} onChanged={refresh} onSelectStudent={handleSelectStudent} />
        ) : (
          <SettingsView />
        )}
      </AppShell>
      <Toaster />
    </>
  );
}
