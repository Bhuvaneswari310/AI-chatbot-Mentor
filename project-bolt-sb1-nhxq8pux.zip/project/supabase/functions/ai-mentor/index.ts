import { createClient } from 'npm:@supabase/supabase-js@2.57.4';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Apikey',
};

const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!;
const SERVICE_ROLE = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
const LLM_KEY = Deno.env.get('OPENAI_API_KEY') ?? '';

function skillPhrase(level: string): string {
  if (level === 'beginner') return 'a beginner — explain fundamentals patiently and avoid jargon, or define it when used';
  if (level === 'advanced') return 'advanced — you can go deep on architecture, performance, and tradeoffs';
  return 'at an intermediate level — balance fundamentals with practical detail';
}

async function llmReply(
  systemPrompt: string,
  history: { role: string; content: string }[],
  userMessage: string,
): Promise<string | null> {
  if (!LLM_KEY) return null;
  const messages = [
    { role: 'system', content: systemPrompt },
    ...history.slice(-10).map((m) => ({
      role: m.role === 'mentor' ? 'assistant' : 'user',
      content: m.content,
    })),
    { role: 'user', content: userMessage },
  ];
  try {
    const res = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: { Authorization: `Bearer ${LLM_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: 'gpt-4o-mini', messages, temperature: 0.6, max_tokens: 500 }),
    });
    if (!res.ok) return null;
    const data = await res.json();
    return data.choices[0].message.content.trim();
  } catch {
    return null;
  }
}

interface ReviewFinding {
  title: string;
  severity: string;
  category: string | null;
  explanation: string | null;
  fix: string | null;
  resolved: boolean;
}

function buildContextBlock(
  student: { name: string; project_title: string; domain: string | null; skill_level: string },
  requirements: { description: string; is_mandatory: boolean }[],
  latestReview: { score: number; state: string; summary: string | null } | null,
  findings: ReviewFinding[],
): string {
  const parts: string[] = [];
  parts.push(`Student: ${student.name}`);
  parts.push(`Project: ${student.project_title}`);
  if (student.domain) parts.push(`Domain: ${student.domain}`);
  parts.push(`Skill level: ${student.skill_level}`);
  if (requirements.length) {
    parts.push('Project requirements:');
    for (const r of requirements) parts.push(`  - [${r.is_mandatory ? 'mandatory' : 'optional'}] ${r.description}`);
  }
  if (latestReview) {
    parts.push(`Latest review: score ${latestReview.score}/100, state ${latestReview.state}`);
    if (latestReview.summary) parts.push(`Review summary: ${latestReview.summary}`);
  }
  if (findings.length) {
    parts.push('Open review findings:');
    for (const f of findings.slice(0, 12)) {
      parts.push(`  - [${f.severity}] ${f.title}${f.resolved ? ' (resolved)' : ''}`);
    }
  }
  return parts.join('\n');
}

function heuristicReply(
  message: string,
  context: string,
  findings: ReviewFinding[],
  skillLevel: string,
): string {
  const lower = message.toLowerCase();
  const open = findings.filter((f) => !f.resolved && f.severity !== 'passed');

  if (/^(hi|hello|hey|good (morning|afternoon|evening))/.test(lower)) {
    const lead = open.length
      ? `You've got ${open.length} open item${open.length > 1 ? 's' : ''} from the last review. The most important one is "${open[0].title}". Want to start there?`
      : `There are no open issues from the last review right now. What would you like to work on?`;
    return `Hi! Good to hear from you. ${lead}`;
  }

  if (/(thank|thanks|appreciate)/.test(lower)) {
    return `You're welcome — you're putting in real effort, and that shows. Keep going, and ping me whenever something feels unclear.`;
  }

  if (/(not working|doesn't work|error|exception|failing|broken|stuck)/.test(lower)) {
    return `Okay, let's take it step by step. Can you share the exact error message or the output you're seeing? Even a screenshot described in words helps. Once I can see what the program is telling you, we can trace it back to the line that's causing it.`;
  }

  if (/(fixed|corrected|updated|done|resubmit)/.test(lower)) {
    if (open.length === 0) {
      return `Great — if you've addressed everything from the last review, go ahead and resubmit the updated project. I'll run a fresh review and compare it against the previous version to confirm what actually improved.`;
    }
    const next = open[0];
    return `Nice progress. Before you resubmit, let's double-check one thing: "${next.title}". ${next.explanation ?? ''} Once that's handled too, resubmit and I'll verify it against the last review.`;
  }

  if (/(explain|what is|what does|how do|how does|why)/.test(lower)) {
    const matched = open.find((f) =>
      lower.split(/\s+/).some((w) => w.length > 4 && f.title.toLowerCase().includes(w)),
    );
    if (matched) {
      return `Good question. "${matched.title}" — here's the idea: ${matched.explanation ?? 'It relates to how the project is structured.'} The reason it matters is that it affects correctness and how others read your work. A practical way to fix it: ${matched.fix ?? 'break it down into a small change and test it.'} Want me to go deeper on any part of that?`;
    }
    return `Happy to explain. Could you tell me which part you'd like me to dig into? If it's about a specific finding from the review, mention the title and I'll walk through the why and the fix in detail.`;
  }

  if (open.length) {
    const top = open[0];
    return `Let's focus on the most pressing item from your last review: "${top.title}". ${top.explanation ?? ''} The suggested fix is: ${top.fix ?? 'work through it methodically and test as you go.'} Try that, and tell me what happens — even a partial attempt is useful, and we'll refine it together.`;
  }

  return `I'm here to help with your project "${context.split('\n')[1]?.replace('Project: ', '') ?? ''}". Tell me what you're working on right now — a bug, a feature you're unsure about, or a review finding you'd like explained — and we'll work through it together. Since you're ${skillPhrase(skillLevel)}, I'll adjust how deep I go.`;
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') return new Response(null, { status: 200, headers: corsHeaders });
  try {
    const { student_id, message } = await req.json();
    if (!student_id || !message) throw new Error('student_id and message are required');

    const sb = createClient(SUPABASE_URL, SERVICE_ROLE, { auth: { persistSession: false } });

    const { data: student } = await sb.from('students').select('*').eq('id', student_id).maybeSingle();
    if (!student) throw new Error('Student not found');

    const { data: requirements } = await sb
      .from('requirements')
      .select('description, is_mandatory')
      .eq('student_id', student_id);

    const { data: latestSubmission } = await sb
      .from('submissions')
      .select('id')
      .eq('student_id', student_id)
      .order('version', { ascending: false })
      .limit(1)
      .maybeSingle();

    let latestReview: { score: number; state: string; summary: string | null } | null = null;
    let findings: ReviewFinding[] = [];
    if (latestSubmission) {
      const { data: rev } = await sb
        .from('reviews')
        .select('id, score, state, summary')
        .eq('submission_id', latestSubmission.id)
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle();
      if (rev) {
        latestReview = rev;
        const { data: items } = await sb
          .from('review_items')
          .select('title, severity, category, explanation, fix, resolved')
          .eq('review_id', rev.id);
        findings = items ?? [];
      }
    }

    const { data: history } = await sb
      .from('chat_messages')
      .select('role, content')
      .eq('student_id', student_id)
      .order('created_at', { ascending: true })
      .limit(20);

    const context = buildContextBlock(student, requirements ?? [], latestReview, findings);

    const systemPrompt = `You are a friendly, patient, experienced technical mentor for an intern. You speak naturally and conversationally, like a supportive senior engineer pair-programming with them — not like a chatbot. The student is ${skillPhrase(student.skill_level)}.

Use this project context to ground every answer:
${context}

Guidelines:
- Be warm and encouraging, never condescending.
- Ask a guiding question before handing over a complete solution when it helps learning.
- Explain the why behind mistakes, with examples tied to their actual project.
- Keep replies concise (2-5 sentences usually). Avoid bullet-point dumps in normal chat.
- Never say "As an AI language model." If asked whether you are AI, answer honestly.
- Do not invent errors or details not in the context. If you don't know, say so.`;

    let reply: string | null = await llmReply(systemPrompt, history ?? [], message);
    let model = 'gpt-4o-mini';
    if (!reply) {
      reply = heuristicReply(message, context, findings, student.skill_level);
      model = 'heuristic (test mode)';
    }

    await sb.from('chat_messages').insert([
      { student_id, role: 'student', content: message },
      { student_id, role: 'mentor', content: reply },
    ]);

    return new Response(
      JSON.stringify({ message: reply, model, test_mode: !LLM_KEY }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ error: err instanceof Error ? err.message : 'Unknown error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
    );
  }
});
