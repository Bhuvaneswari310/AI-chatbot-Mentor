import { createClient } from 'npm:@supabase/supabase-js@2.57.4';
import { renderFromTemplate, type EmailTemplateType, type TemplateContext } from '../_shared/email-templates.ts';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Apikey',
};

const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!;
const SERVICE_ROLE = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;

function fmtDate(d: string | null): string {
  if (!d) return 'to be confirmed';
  try {
    return new Date(d).toLocaleString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  } catch {
    return d;
  }
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') return new Response(null, { status: 200, headers: corsHeaders });
  try {
    const { student_id, type, review_id } = await req.json();
    if (!student_id || !type) throw new Error('student_id and type are required');

    const validTypes: EmailTemplateType[] = ['review_update', 'reminder', 'overdue', 'resubmission', 'approval'];
    if (!validTypes.includes(type as EmailTemplateType)) {
      throw new Error(`Invalid email type. Must be one of: ${validTypes.join(', ')}`);
    }

    const sb = createClient(SUPABASE_URL, SERVICE_ROLE, { auth: { persistSession: false } });

    const { data: student } = await sb.from('students').select('*').eq('id', student_id).maybeSingle();
    if (!student) throw new Error('Student not found');

    const { data: schedule } = await sb
      .from('schedules')
      .select('review_at, mode, venue, meet_url, submission_deadline')
      .eq('student_id', student_id)
      .order('review_at', { ascending: false })
      .limit(1)
      .maybeSingle();

    const { data: settingsRows } = await sb.from('settings').select('key, value');
    const settings = Object.fromEntries((settingsRows ?? []).map((s) => [s.key, s.value]));

    const scheduleLines: string[] = [];
    if (schedule) {
      scheduleLines.push(`Next review: ${fmtDate(schedule.review_at)}`);
      scheduleLines.push(`Format: ${schedule.mode === 'online' ? 'Online meeting' : 'In person'}`);
      if (schedule.mode === 'online' && schedule.meet_url) scheduleLines.push(`Meeting link: ${schedule.meet_url}`);
      if (schedule.mode === 'in_person' && schedule.venue) scheduleLines.push(`Venue: ${schedule.venue}`);
      if (schedule.submission_deadline) scheduleLines.push(`Submission deadline: ${fmtDate(schedule.submission_deadline)}`);
    } else {
      scheduleLines.push('Next review: to be confirmed — your coordinator will reach out with details.');
    }

    const ctx: TemplateContext = {
      student_name: student.name,
      project_title: student.project_title,
      student_email: student.email ?? '',
      status: student.status ?? '',
      status_label: student.status === 'approved' ? 'Approved / Completed' : student.status === 'ready_for_review' ? 'Ready for Mentor Review' : 'Needs Correction',
      score: '',
      summary: '',
      what_improved: '',
      what_remains: '',
      findings: '',
      next_review: scheduleLines.join('\n'),
      review_format: schedule?.mode === 'online' ? 'Online meeting' : schedule?.mode === 'in_person' ? 'In person' : 'to be confirmed',
      meeting_link: schedule?.meet_url ?? '',
      venue: schedule?.venue ?? '',
      submission_deadline: schedule?.submission_deadline ? fmtDate(schedule.submission_deadline) : '',
      org_name: settings.org_name ?? 'Internship Program',
      coordinator_name: settings.coordinator_name ?? 'Program Coordinator',
      coordinator_email: settings.coordinator_email ?? '',
      coordinator_phone: settings.coordinator_phone ?? '',
    };

    const { subject, body } = renderFromTemplate(type as EmailTemplateType, settings, ctx);

    const { data: emailRow } = await sb
      .from('email_log')
      .insert({ student_id, review_id: review_id ?? null, subject, body, email_type: type, sent: false })
      .select()
      .maybeSingle();

    return new Response(
      JSON.stringify({ subject, body, email_id: emailRow?.id ?? null }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ error: err instanceof Error ? err.message : 'Unknown error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
    );
  }
});
