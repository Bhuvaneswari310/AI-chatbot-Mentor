import { createClient } from 'npm:@supabase/supabase-js@2.57.4';
import { renderFromTemplate, type EmailTemplateType, type TemplateContext } from '../_shared/email-templates.ts';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Apikey',
};

const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!;
const SERVICE_ROLE = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
const LLM_KEY = Deno.env.get('OPENAI_API_KEY') ?? '';

interface SeverityCounts {
  error: number;
  warning: number;
  improvement: number;
  passed: number;
}

interface Finding {
  severity: 'error' | 'warning' | 'improvement' | 'passed';
  category: string;
  title: string;
  explanation: string;
  fix: string;
}

const LANGUAGE_PATTERNS: Record<string, RegExp[]> = {
  python: [/^\s*def\s+\w+/m, /^\s*import\s+\w+/m, /^\s*from\s+\w+\s+import/m, /print\(/],
  javascript: [/\bfunction\s+\w+\s*\(/, /\bconst\s+\w+\s*=/, /\bconsole\.log\(/, /=>\s*[{(]?/],
  java: [/public\s+(static\s+)?(class|void|String|int)\b/, /System\.out\.print/],
  cpp: [/#include\s*</, /std::cout/, /int\s+main\s*\(/],
  sql: [/^\s*SELECT\b/im, /^\s*CREATE\s+TABLE\b/im, /^\s*INSERT\s+INTO\b/im],
  html: [/<html|<!doctype/i, /<div|<span|<p>/i],
  css: [/\{[^}]*:[^}]*;/, /@media|@import/],
};

function detectLanguages(content: string): string[] {
  const found: string[] = [];
  for (const [lang, patterns] of Object.entries(LANGUAGE_PATTERNS)) {
    if (patterns.some((p) => p.test(content))) found.push(lang);
  }
  return found.length ? found : ['text'];
}

function analyzeSecurity(content: string): Finding[] {
  const findings: Finding[] = [];
  const lower = content.toLowerCase();

  if (/password\s*=\s*["'][^"']+["']/i.test(content) || /api[_-]?key\s*=\s*["'][^"']+["']/i.test(content)) {
    findings.push({
      severity: 'error',
      category: 'Security',
      title: 'Hardcoded secret detected',
      explanation:
        'A password or API key appears as a literal string in the source code. Anyone with access to the code or a compiled binary can read it. This is a common cause of leaked credentials.',
      fix: 'Move secrets into environment variables or a secrets manager. Read them at runtime (e.g. os.environ["API_KEY"]) and never commit the real value to version control.',
    });
  }
  if (/eval\s*\(/.test(content) && /(input|request|req\.)/i.test(content)) {
    findings.push({
      severity: 'error',
      category: 'Security',
      title: 'Use of eval() with input',
      explanation:
        'eval() executes arbitrary code. If it is fed user input, an attacker can run any code in your program — this is a remote code execution vulnerability.',
      fix: 'Parse the input with a safe parser instead. If you must evaluate expressions, use a sandboxed library like ast.literal_eval for Python literals.',
    });
  }
  if (/(SELECT|INSERT|UPDATE|DELETE).*\+.*\w+.*FROM|f["'].*\{.*\}.*SELECT/i.test(content)) {
    findings.push({
      severity: 'error',
      category: 'Security',
      title: 'Possible SQL injection (string-built query)',
      explanation:
        'A SQL statement appears to be built by concatenating values. When user-controlled data is concatenated into SQL, an attacker can alter the query meaning.',
      fix: 'Use parameterized queries / prepared statements. Pass values as parameters, not as part of the query string.',
    });
  }
  if (/(innerHTML|document\.write)\s*=/.test(content) && /(input|location|data)/i.test(content)) {
    findings.push({
      severity: 'warning',
      category: 'Security',
      title: 'Possible XSS sink',
      explanation:
        'Content is written to the DOM via innerHTML or document.write. If that content comes from user input or the URL, script can be injected into the page.',
      fix: 'Set textContent instead of innerHTML when you only need text. If you must insert HTML, sanitize it first with a library like DOMPurify.',
    });
  }
  return findings;
}

function analyzeCodeQuality(content: string, langs: string[]): Finding[] {
  const findings: Finding[] = [];
  const lines = content.split('\n');
  const lineCount = lines.length;

  const todoCount = (content.match(/\b(TODO|FIXME|XXX)\b/g) || []).length;
  if (todoCount > 0) {
    findings.push({
      severity: 'warning',
      category: 'Completeness',
      title: `${todoCount} unresolved TODO/FIXME marker${todoCount > 1 ? 's' : ''}`,
      explanation:
        'TODO and FIXME markers indicate incomplete work. A reviewer cannot tell which are planned versus forgotten.',
      fix: 'Resolve each marker or convert it to a tracked issue with an owner and due date.',
    });
  }

  let longFunctions = 0;
  if (langs.includes('python') || langs.includes('javascript')) {
    let depth = 0;
    let start = 0;
    lines.forEach((ln, i) => {
      const defMatch = /^\s*(def |function |const \w+ = (?:async )?\(?.*\)? =>)/.exec(ln);
      if (defMatch && depth === 0) start = i;
      const opens = (ln.match(/{/g) || []).length;
      const closes = (ln.match(/}/g) || []).length;
      depth += opens - closes;
      if (defMatch && depth === 0 && i - start > 60) longFunctions++;
    });
  }
  if (longFunctions > 0) {
    findings.push({
      severity: 'improvement',
      category: 'Maintainability',
      title: `${longFunctions} function(s) longer than ~60 lines`,
      explanation:
        'Long functions are hard to read, test, and reuse. They usually mix several responsibilities.',
      fix: 'Extract logical steps into smaller named helper functions, each doing one thing. Aim for functions you can name in a single sentence.',
    });
  }

  const commentedOut = lines.filter((l) => /^\s*(#|\/\/)\s*(print|console|return|if|def|function|const)/.test(l)).length;
  if (commentedOut > 3) {
    findings.push({
      severity: 'improvement',
      category: 'Cleanliness',
      title: `${commentedOut} lines of commented-out code`,
      explanation:
        'Commented-out code accumulates and confuses readers — nobody knows if it is still needed.',
      fix: 'Delete commented-out code. Your version control history keeps it if you need it later.',
    });
  }

  const blankRatio = lines.filter((l) => l.trim() === '').length / Math.max(lineCount, 1);
  if (lineCount > 40 && blankRatio < 0.05) {
    findings.push({
      severity: 'improvement',
      category: 'Readability',
      title: 'Very little whitespace between code blocks',
      explanation:
        'Code with no blank lines between logical groups is harder to scan. Readers rely on whitespace to separate ideas.',
      fix: 'Insert a blank line between function definitions and between logical sections inside longer functions.',
    });
  }
  return findings;
}

function analyzeDocumentation(content: string, langs: string[]): Finding[] {
  const findings: Finding[] = [];

  const defCount =
    (content.match(/^\s*def\s+\w+/gm) || []).length +
    (content.match(/\bfunction\s+\w+\s*\(/g) || []).length;

  const docCount =
    (content.match(/"""/g) || []).length / 2 +
    (content.match(/\/\*\*/g) || []).length +
    (content.match(/^\s*\/\/\s*\w/gm) || []).length;

  if (defCount > 0 && docCount / Math.max(defCount, 1) < 0.3) {
    findings.push({
      severity: 'warning',
      category: 'Documentation',
      title: 'Few functions have docstrings or comments',
      explanation:
        'Other developers (and your future self) need to understand what each function does, what it expects, and what it returns. Without documentation they must read every line.',
      fix: 'Add a short docstring to each function describing its purpose, parameters, and return value. One or two sentences is enough.',
    });
  }

  if (langs.includes('python')) {
    const hasMainGuard = /if\s+__name__\s*==\s*['"]__main__['"]/.test(content);
    const hasFunctions = defCount > 0;
    if (hasFunctions && !hasMainGuard) {
      findings.push({
        severity: 'improvement',
        category: 'Structure',
        title: 'No __main__ guard',
        explanation:
          'Without an if __name__ == "__main__" guard, top-level code runs when the file is imported, which can cause side effects in tests or other modules.',
        fix: 'Wrap any executable top-level code in a main() function and call it under the __main__ guard.',
      });
    }
  }
  return findings;
}

function analyzeErrors(content: string): Finding[] {
  const findings: Finding[] = [];
  if (/except\s*:/.test(content) || /catch\s*\(\s*\w*\s*\)\s*\{/.test(content)) {
    if (/except\s*:/.test(content)) {
      findings.push({
        severity: 'warning',
        category: 'Error handling',
        title: 'Bare except clause',
        explanation:
          'A bare `except:` catches every exception including KeyboardInterrupt and SystemExit, which can hide real bugs and make the program hard to stop.',
        fix: 'Catch the specific exceptions you expect (e.g. `except ValueError:`). Let unexpected errors propagate so they surface during testing.',
      });
    }
  }
  if (/print\s*\(/.test(content) && /except/.test(content)) {
    const swallow = /except[^:]*:\s*\n\s*pass/.test(content);
    if (swallow) {
      findings.push({
        severity: 'warning',
        category: 'Error handling',
        title: 'Exception silently swallowed (except: pass)',
        explanation:
          'Catching an exception and doing nothing (pass) hides failures. The program keeps running in an inconsistent state and bugs become invisible.',
        fix: 'At minimum log the exception. Decide whether to recover, re-raise, or surface a clear error to the user.',
      });
    }
  }
  return findings;
}

function analyzeRequirements(content: string, requirements: { description: string; is_mandatory: boolean }[]): Finding[] {
  const findings: Finding[] = [];
  const lower = content.toLowerCase();
  for (const req of requirements) {
    const keywords = req.description
      .toLowerCase()
      .split(/\s+/)
      .filter((w) => w.length > 4 && !['should', 'would', 'could', 'system', 'project', 'student'].includes(w));
    const hits = keywords.filter((k) => lower.includes(k)).length;
    const ratio = keywords.length ? hits / keywords.length : 0;
    if (ratio > 0.4) {
      findings.push({
        severity: 'passed',
        category: 'Requirements',
        title: `Requirement addressed: "${req.description.slice(0, 60)}"`,
        explanation: `Keywords from this requirement appear in the submission, suggesting it has been attempted.`,
        fix: req.is_mandatory
          ? 'Confirm it works end-to-end with a test, not just that the code mentions it.'
          : 'Optional — verify the implementation if time allows.',
      });
    } else if (req.is_mandatory && ratio <= 0.1) {
      findings.push({
        severity: 'error',
        category: 'Requirements',
        title: `Missing requirement: "${req.description.slice(0, 60)}"`,
        explanation: `This mandatory requirement does not appear to be addressed in the submission. The reviewer could not find evidence of it.`,
        fix: `Implement this requirement and, if it is not obvious, mention where it lives in your resubmission notes.`,
      });
    } else if (req.is_mandatory && ratio <= 0.4) {
      findings.push({
        severity: 'warning',
        category: 'Requirements',
        title: `Requirement partially addressed: "${req.description.slice(0, 60)}"`,
        explanation: `Some related keywords appear, but the requirement does not look fully implemented.`,
        fix: `Complete the implementation and add a note explaining how it satisfies the requirement.`,
      });
    }
  }
  return findings;
}

function computeScore(findings: Finding[], requirements: { is_mandatory: boolean }[]): number {
  const mandatoryCount = requirements.filter((r) => r.is_mandatory).length || 1;
  const errors = findings.filter((f) => f.severity === 'error');
  const reqErrors = errors.filter((f) => f.category === 'Requirements').length;
  const otherErrors = errors.filter((f) => f.category !== 'Requirements').length;
  const warnings = findings.filter((f) => f.severity === 'warning').length;

  let score = 100;
  score -= Math.min(45, (reqErrors / mandatoryCount) * 45);
  score -= Math.min(20, otherErrors * 7);
  score -= Math.min(15, warnings * 4);
  score = Math.max(0, Math.round(score));
  return score;
}

function decideState(score: number, findings: Finding[]): 'needs_correction' | 'ready_for_review' | 'approved' {
  const hasErrors = findings.some((f) => f.severity === 'error');
  if (hasErrors || score < 60) return 'needs_correction';
  if (score < 85) return 'ready_for_review';
  return 'ready_for_review';
}

function buildSummary(findings: Finding[], score: number): string {
  const errors = findings.filter((f) => f.severity === 'error').length;
  const warnings = findings.filter((f) => f.severity === 'warning').length;
  const passed = findings.filter((f) => f.severity === 'passed').length;
  const parts = [`Score: ${score}/100.`];
  if (errors) parts.push(`${errors} error${errors > 1 ? 's' : ''} must be fixed before approval.`);
  else parts.push('No blocking errors were found.');
  if (warnings) parts.push(`${warnings} warning${warnings > 1 ? 's' : ''} to review.`);
  if (passed) parts.push(`${passed} requirement${passed > 1 ? 's' : ''} appear addressed.`);
  return parts.join(' ');
}

function compareWithPrevious(
  findings: Finding[],
  prevFindings: { title: string; severity: string; resolved: boolean }[],
): { improved: string; remains: string } {
  const prevTitles = new Set(prevFindings.map((f) => f.title));
  const newTitles = new Set(findings.map((f) => f.title));
  const fixed = [...prevTitles].filter((t) => !newTitles.has(t));
  const introduced = [...newTitles].filter((t) => !prevTitles.has(t));
  const stillPresent = [...newTitles].filter((t) => prevTitles.has(t));

  const improved = fixed.length
    ? `Resolved since last review: ${fixed.slice(0, 5).join('; ')}.`
    : 'No previously reported issues were confirmed as resolved.';
  const remains = [
    stillPresent.length ? `Still outstanding: ${stillPresent.slice(0, 5).join('; ')}.` : '',
    introduced.length ? `New findings this round: ${introduced.slice(0, 5).join('; ')}.` : '',
  ]
    .filter(Boolean)
    .join(' ');
  return { improved, remains };
}

async function llmReview(
  content: string,
  requirements: { description: string; is_mandatory: boolean }[],
  previousFindings: { title: string; severity: string }[],
  skillLevel: string,
): Promise<{ findings: Finding[]; summary: string; model: string } | null> {
  if (!LLM_KEY) return null;
  const prompt = `You are a senior technical mentor reviewing an intern's project submission.

Skill level: ${skillLevel}
Requirements:
${requirements.map((r) => `- [${r.is_mandatory ? 'MANDATORY' : 'optional'}] ${r.description}`).join('\n')}

Previously reported issues (check whether each is fixed):
${previousFindings.map((f) => `- ${f.severity}: ${f.title}`).join('\n') || 'None (first review).'}

Submission content:
"""
${content.slice(0, 12000)}
"""

Respond ONLY with JSON of this exact shape:
{"findings":[{"severity":"error|warning|improvement|passed","category":"...","title":"...","explanation":"why it is wrong/what is good","fix":"concrete step or code"}],"summary":"2-3 sentence review summary"}
Do not invent errors. Only report issues you can see in the content. Mark clearly confirmed issues as "error", likely ones as "warning", and nice-to-haves as "improvement".`;

  try {
    const res = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: { Authorization: `Bearer ${LLM_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages: [{ role: 'user', content: prompt }],
        response_format: { type: 'json_object' },
        temperature: 0.2,
      }),
    });
    if (!res.ok) return null;
    const data = await res.json();
    const parsed = JSON.parse(data.choices[0].message.content);
    return { findings: parsed.findings, summary: parsed.summary, model: 'gpt-4o-mini' };
  } catch {
    return null;
  }
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') return new Response(null, { status: 200, headers: corsHeaders });
  try {
    const { student_id } = await req.json();
    if (!student_id) throw new Error('student_id is required');

    const sb = createClient(SUPABASE_URL, SERVICE_ROLE, { auth: { persistSession: false } });

    const { data: student } = await sb
      .from('students')
      .select('*')
      .eq('id', student_id)
      .maybeSingle();
    if (!student) throw new Error('Student not found');

    const { data: requirements } = await sb
      .from('requirements')
      .select('description, is_mandatory')
      .eq('student_id', student_id);

    const { data: submissions } = await sb
      .from('submissions')
      .select('*')
      .eq('student_id', student_id)
      .order('version', { ascending: false });

    if (!submissions || submissions.length === 0) {
      throw new Error('No submissions found for this student');
    }
    const latest = submissions[0];
    const previous = submissions[1] ?? null;

    let prevFindings: { title: string; severity: string; resolved: boolean }[] = [];
    if (previous) {
      const { data: prevReview } = await sb
        .from('reviews')
        .select('id')
        .eq('submission_id', previous.id)
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle();
      if (prevReview) {
        const { data: prevItems } = await sb
          .from('review_items')
          .select('title, severity, resolved')
          .eq('review_id', prevReview.id);
        prevFindings = prevItems ?? [];
      }
    }

    const content = latest.content ?? '';
    const reqList = (requirements ?? []).map((r) => ({ description: r.description, is_mandatory: r.is_mandatory }));

    let findings: Finding[];
    let summary: string;
    let model: string;

    const llm = await llmReview(content, reqList, prevFindings, student.skill_level);
    if (llm) {
      findings = llm.findings;
      summary = llm.summary;
      model = llm.model;
    } else {
      const langs = detectLanguages(content);
      findings = [
        ...analyzeSecurity(content),
        ...analyzeErrors(content),
        ...analyzeRequirements(content, reqList),
        ...analyzeCodeQuality(content, langs),
        ...analyzeDocumentation(content, langs),
      ];
      if (findings.length === 0) {
        findings.push({
          severity: 'passed',
          category: 'Overall',
          title: 'No obvious issues found by static analysis',
          explanation:
            'The automated checks did not find blocking errors, security issues, or missing mandatory requirements. This does not prove the project is correct — only that common problems were not detected.',
          fix: 'Add tests covering the main flows and verify the expected output manually.',
        });
      }
      const score = computeScore(findings, reqList);
      summary = buildSummary(findings, score);
      model = 'static-analysis (test mode)';
    }

    const score = computeScore(findings, reqList);
    const state = decideState(score, findings);
    const { improved, remains } = compareWithPrevious(findings, prevFindings);

    const reviewNumber = ((submissions.length > 0 ? (await sb.from('reviews').select('id').eq('student_id', student_id)) : { data: [] }).data?.length ?? 0) + 1;

    const { data: reviewRow, error: revErr } = await sb
      .from('reviews')
      .insert({
        student_id,
        submission_id: latest.id,
        review_number: reviewNumber,
        score,
        state,
        summary,
        what_improved: improved,
        what_remains: remains,
        ai_model: model,
      })
      .select()
      .maybeSingle();
    if (revErr || !reviewRow) throw new Error('Failed to create review');

    const itemRows = findings.map((f) => ({
      review_id: reviewRow.id,
      severity: f.severity,
      category: f.category,
      title: f.title,
      explanation: f.explanation,
      fix: f.fix,
      resolved: false,
    }));
    const { error: itemErr } = await sb.from('review_items').insert(itemRows);
    if (itemErr) throw new Error('Failed to save review items');

    await sb.from('students').update({ status: state, updated_at: new Date().toISOString() }).eq('id', student_id);

    const { data: settingsRows } = await sb.from('settings').select('key, value');
    const settings = Object.fromEntries((settingsRows ?? []).map((s) => [s.key, s.value]));

    const { data: schedule } = await sb
      .from('schedules')
      .select('review_at, mode, venue, meet_url, submission_deadline')
      .eq('student_id', student_id)
      .order('review_at', { ascending: false })
      .limit(1)
      .maybeSingle();

    const statusLabel =
      state === 'approved' ? 'Approved / Completed'
      : state === 'ready_for_review' ? 'Ready for Mentor Review'
      : 'Needs Correction';

    const findingsText = findings
      .filter((f) => f.severity !== 'passed')
      .map((f, i) => `${i + 1}. [${f.severity.toUpperCase()}] ${f.title}\n   Why: ${f.explanation}\n   Fix: ${f.fix}`)
      .join('\n');

    const scheduleLines: string[] = [];
    if (schedule) {
      scheduleLines.push(`Next review: ${fmtDate(schedule.review_at)}`);
      scheduleLines.push(`Format: ${schedule.mode === 'online' ? 'Online meeting' : 'In person'}`);
      if (schedule.mode === 'online' && schedule.meet_url) scheduleLines.push(`Meeting link: ${schedule.meet_url}`);
      if (schedule.mode === 'in_person' && schedule.venue) scheduleLines.push(`Venue: ${schedule.venue}`);
      if (schedule.submission_deadline) scheduleLines.push(`Submission deadline: ${fmtDate(schedule.submission_deadline)}`);
    } else {
      scheduleLines.push('Next review: to be confirmed — your coordinator will reach out with details.');
    }

    const ctx: TemplateContext = {
      student_name: student.name,
      project_title: student.project_title,
      student_email: student.email ?? '',
      status: state,
      status_label: statusLabel,
      score: String(score),
      summary,
      what_improved: improved,
      what_remains: remains,
      findings: findingsText,
      next_review: scheduleLines.join('\n'),
      review_format: schedule?.mode === 'online' ? 'Online meeting' : schedule?.mode === 'in_person' ? 'In person' : 'to be confirmed',
      meeting_link: schedule?.meet_url ?? '',
      venue: schedule?.venue ?? '',
      submission_deadline: schedule?.submission_deadline ? fmtDate(schedule.submission_deadline) : '',
      org_name: settings.org_name ?? 'Internship Program',
      coordinator_name: settings.coordinator_name ?? 'Program Coordinator',
      coordinator_email: settings.coordinator_email ?? '',
      coordinator_phone: settings.coordinator_phone ?? '',
    };

    const templateType: EmailTemplateType = state === 'approved' ? 'approval' : 'review_update';
    const { subject, body } = renderFromTemplate(templateType, settings, ctx);

    const { data: emailRow } = await sb
      .from('email_log')
      .insert({
        student_id,
        review_id: reviewRow.id,
        subject,
        body,
        email_type: state === 'approved' ? 'approval' : 'review_update',
        sent: false,
      })
      .select()
      .maybeSingle();

    // Attempt to send the email via SMTP if configured.
    // Uses EdgeRuntime.waitUntil so the review response isn't blocked on email delivery.
    let emailSent = false;
    let emailError: string | null = null;
    try {
      const sendRes = await fetch(`${SUPABASE_URL}/functions/v1/send-email`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${SERVICE_ROLE}`,
        },
        body: JSON.stringify({ action: 'send_latest', student_id }),
      });
      const sendJson = await sendRes.json();
      emailSent = !!sendJson.ok;
      if (!sendJson.ok && sendJson.configured !== false) {
        emailError = sendJson.error ?? 'Unknown send error';
      }
    } catch {
      emailError = 'Failed to reach send-email function';
    }

    return new Response(
      JSON.stringify({
        review: { ...reviewRow, review_items: itemRows.map((r, i) => ({ ...r, id: 'tmp_' + i })) },
        items: itemRows,
        email_subject: subject,
        email_body: body,
        email_id: emailRow?.id ?? null,
        email_sent: emailSent,
        email_error: emailError,
        test_mode: !LLM_KEY,
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ error: err instanceof Error ? err.message : 'Unknown error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
    );
  }
});

function fmtDate(d: string | null): string {
  if (!d) return 'to be confirmed';
  try {
    return new Date(d).toLocaleString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  } catch {
    return d;
  }
}


