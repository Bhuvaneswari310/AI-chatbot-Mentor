// Shared email template engine used by ai-review and render-email edge functions.
// Templates are stored as rows in the `settings` table (key = template_<type>, value = body text).
// Each template supports {{placeholder}} interpolation. If a template is missing, a built-in default is used.

export type EmailTemplateType = 'review_update' | 'reminder' | 'overdue' | 'resubmission' | 'approval';

export interface TemplateContext {
  student_name: string;
  project_title: string;
  student_email: string;
  status: string;
  status_label: string;
  score: string;
  summary: string;
  what_improved: string;
  what_remains: string;
  findings: string;
  next_review: string;
  review_format: string;
  meeting_link: string;
  venue: string;
  submission_deadline: string;
  org_name: string;
  coordinator_name: string;
  coordinator_email: string;
  coordinator_phone: string;
}

const DEFAULT_TEMPLATES: Record<EmailTemplateType, { subject: string; body: string }> = {
  review_update: {
    subject: 'Internship Project Review Update – {{project_title}} – {{student_name}}',
    body: `Dear {{student_name}},

Here is the latest review update for your internship project "{{project_title}}".

Current status: {{status_label}}
Review score: {{score}}/100

Summary: {{summary}}

{{what_improved}}
{{what_remains}}

Findings and required actions:
{{findings}}

{{next_review}}

Please address the items above and resubmit your updated project before the deadline.

Wishing you the best,
{{coordinator_name}}
{{org_name}}
{{coordinator_email}}
{{coordinator_phone}}`,
  },
  reminder: {
    subject: 'Upcoming Review Reminder – {{project_title}} – {{student_name}}',
    body: `Dear {{student_name}},

This is a friendly reminder about your upcoming project review for "{{project_title}}".

{{next_review}}

If you have any questions, just reply to this thread or reach out using the contact details below.

Wishing you the best,
{{coordinator_name}}
{{org_name}}
{{coordinator_email}}
{{coordinator_phone}}`,
  },
  overdue: {
    subject: 'Overdue Correction – {{project_title}} – {{student_name}}',
    body: `Dear {{student_name}},

Our records show that corrections for your project "{{project_title}}" are now overdue. Please prioritize completing them so we can schedule your next review.

{{next_review}}

If you have any questions, just reply to this thread or reach out using the contact details below.

Wishing you the best,
{{coordinator_name}}
{{org_name}}
{{coordinator_email}}
{{coordinator_phone}}`,
  },
  resubmission: {
    subject: 'Resubmission Received – {{project_title}} – {{student_name}}',
    body: `Dear {{student_name}},

We've received your updated submission for "{{project_title}}". A new review will be generated shortly, and you'll receive the feedback by email.

{{next_review}}

If you have any questions, just reply to this thread or reach out using the contact details below.

Wishing you the best,
{{coordinator_name}}
{{org_name}}
{{coordinator_email}}
{{coordinator_phone}}`,
  },
  approval: {
    subject: 'Project Approved – {{project_title}} – {{student_name}}',
    body: `Dear {{student_name}},

Congratulations! Your internship project "{{project_title}}" has been reviewed and approved. Great work reaching this milestone.

{{next_review}}

If you have any questions, just reply to this thread or reach out using the contact details below.

Wishing you the best,
{{coordinator_name}}
{{org_name}}
{{coordinator_email}}
{{coordinator_phone}}`,
  },
};

export function interpolate(template: string, ctx: TemplateContext): string {
  return template.replace(/\{\{(\w+)\}\}/g, (_match, key: string) => {
    const val = (ctx as Record<string, string>)[key];
    return val !== undefined && val !== null ? val : '';
  });
}

function cleanLines(text: string): string {
  // Remove lines that are now empty because an optional placeholder resolved to '',
  // but keep intentional blank lines between content.
  return text
    .split('\n')
    .map((line) => line.trimEnd())
    .filter((line, i, arr) => {
      // Collapse runs of 3+ consecutive blank lines into 1, but keep single blank separators
      if (line.trim() === '' && i > 0 && i < arr.length - 1) {
        const prev = arr[i - 1].trim();
        const next = arr[i + 1]?.trim() ?? '';
        if (prev === '' && next === '') return false;
      }
      return true;
    })
    .join('\n')
    .trim();
}

export function renderFromTemplate(
  type: EmailTemplateType,
  settings: Record<string, string>,
  ctx: TemplateContext,
): { subject: string; body: string } {
  const defaults = DEFAULT_TEMPLATES[type];
  const bodyKey = `template_${type}`;
  const subjectKey = `template_${type}_subject`;

  const customBody = settings[bodyKey];
  const customSubject = settings[subjectKey];

  const body = cleanLines(interpolate(customBody ?? defaults.body, ctx));
  const subject = interpolate(customSubject ?? defaults.subject, ctx).trim();

  return { subject, body };
}

export function getTemplateDefaults(): Record<EmailTemplateType, { subject: string; body: string }> {
  return DEFAULT_TEMPLATES;
}
