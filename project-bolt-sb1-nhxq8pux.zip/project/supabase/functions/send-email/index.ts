import { createClient } from 'npm:@supabase/supabase-js@2.57.4';
import nodemailer from 'npm:nodemailer@6.9.16';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Apikey',
};

const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!;
const SERVICE_ROLE = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;

// SMTP credentials — stored ONLY as server-side edge function secrets, never in frontend
const SMTP_HOST = Deno.env.get('SMTP_HOST') ?? '';
const SMTP_PORT = Deno.env.get('SMTP_PORT') ?? '587';
const SMTP_USER = Deno.env.get('SMTP_USER') ?? '';
const SMTP_PASS = Deno.env.get('SMTP_PASS') ?? '';
const SMTP_FROM = Deno.env.get('SMTP_FROM') ?? SMTP_USER;
const SMTP_SECURE = Deno.env.get('SMTP_SECURE') === 'true';

interface SmtpConfig {
  host: string;
  port: number;
  secure: boolean;
  auth: { user: string; pass: string };
}

function getSmtpConfig(): SmtpConfig | null {
  if (!SMTP_HOST || !SMTP_USER || !SMTP_PASS) return null;
  const port = parseInt(SMTP_PORT, 10);
  return {
    host: SMTP_HOST,
    port: isNaN(port) ? 587 : port,
    secure: SMTP_SECURE || port === 465,
    auth: { user: SMTP_USER, pass: SMTP_PASS },
  };
}

async function sendViaSmtp(
  config: SmtpConfig,
  to: string,
  subject: string,
  text: string,
  fromName: string,
): Promise<{ messageId: string }> {
  const transporter = nodemailer.createTransport(config);
  const info = await transporter.sendMail({
    from: `"${fromName}" <${SMTP_FROM}>`,
    to,
    subject,
    text,
  });
  return { messageId: info.messageId };
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') return new Response(null, { status: 200, headers: corsHeaders });
  try {
    const body = await req.json();
    const { action, email_id, student_id, test_to } = body;

    const sb = createClient(SUPABASE_URL, SERVICE_ROLE, { auth: { persistSession: false } });
    const config = getSmtpConfig();

    // --- Test email: verify SMTP works without touching student data ---
    if (action === 'test') {
      if (!config) {
        return new Response(
          JSON.stringify({
            ok: false,
            configured: false,
            error: 'SMTP is not configured. Set SMTP_HOST, SMTP_USER, SMTP_PASS, SMTP_FROM (and optionally SMTP_PORT, SMTP_SECURE) as edge function secrets.',
          }),
          { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
        );
      }

      const target = test_to || SMTP_USER;
      const testSubject = 'Internship Mentor System – SMTP Test';
      const testBody = [
        'This is a test email from the Internship Mentor System.',
        '',
        'If you received this message, your SMTP configuration is working correctly.',
        'Email notifications to students will now be delivered automatically after each review.',
        '',
        'Configuration summary:',
        `  Host: ${config.host}:${config.port}`,
        `  Secure: ${config.secure}`,
        `  From: ${SMTP_FROM}`,
      ].join('\n');

      const { data: settingsRows } = await sb.from('settings').select('key, value');
      const settings = Object.fromEntries((settingsRows ?? []).map((s) => [s.key, s.value]));
      const fromName = settings.org_name ?? 'Internship Mentor System';

      try {
        const result = await sendViaSmtp(config, target, testSubject, testBody, fromName);
        return new Response(
          JSON.stringify({ ok: true, configured: true, messageId: result.messageId, sent_to: target }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
        );
      } catch (e) {
        return new Response(
          JSON.stringify({
            ok: false,
            configured: true,
            error: `SMTP connection failed: ${e instanceof Error ? e.message : 'unknown error'}`,
          }),
          { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
        );
      }
    }

    // --- Send a stored email by its email_log id ---
    if (action === 'send') {
      if (!email_id) throw new Error('email_id is required');
      if (!config) {
        throw new Error('SMTP is not configured. Add SMTP secrets and run a test first.');
      }

      const { data: emailRow } = await sb
        .from('email_log')
        .select('id, student_id, subject, body, sent')
        .eq('id', email_id)
        .maybeSingle();
      if (!emailRow) throw new Error('Email not found');
      if (emailRow.sent) throw new Error('This email was already sent');

      const { data: student } = await sb
        .from('students')
        .select('name, email')
        .eq('id', emailRow.student_id)
        .maybeSingle();
      if (!student) throw new Error('Student not found for this email');
      if (!student.email || !student.email.includes('@')) {
        throw new Error(`Student "${student.name}" has no valid email address (${student.email || 'empty'}). Update the student record before sending.`);
      }

      const { data: settingsRows } = await sb.from('settings').select('key, value');
      const settings = Object.fromEntries((settingsRows ?? []).map((s) => [s.key, s.value]));
      const fromName = settings.org_name ?? 'Internship Mentor System';

      try {
        const result = await sendViaSmtp(config, student.email, emailRow.subject, emailRow.body, fromName);
        await sb.from('email_log').update({ sent: true }).eq('id', email_id);
        return new Response(
          JSON.stringify({ ok: true, messageId: result.messageId, sent_to: student.email }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
        );
      } catch (e) {
        return new Response(
          JSON.stringify({ ok: false, error: `Failed to send: ${e instanceof Error ? e.message : 'unknown error'}` }),
          { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
        );
      }
    }

    // --- Send the latest unsent email for a student (used after review) ---
    if (action === 'send_latest') {
      if (!student_id) throw new Error('student_id is required');
      if (!config) {
        // SMTP not configured — return gracefully so the review flow doesn't break
        return new Response(
          JSON.stringify({ ok: false, configured: false, error: 'SMTP not configured — email saved as draft.' }),
          { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
        );
      }

      const { data: latest } = await sb
        .from('email_log')
        .select('id, subject, body, sent')
        .eq('student_id', student_id)
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle();
      if (!latest) throw new Error('No email found for this student');
      if (latest.sent) {
        return new Response(
          JSON.stringify({ ok: true, already_sent: true }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
        );
      }

      const { data: student } = await sb
        .from('students')
        .select('name, email')
        .eq('id', student_id)
        .maybeSingle();
      if (!student || !student.email || !student.email.includes('@')) {
        return new Response(
          JSON.stringify({ ok: false, error: `Cannot send: student has no valid email address.` }),
          { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
        );
      }

      const { data: settingsRows } = await sb.from('settings').select('key, value');
      const settings = Object.fromEntries((settingsRows ?? []).map((s) => [s.key, s.value]));
      const fromName = settings.org_name ?? 'Internship Mentor System';

      try {
        const result = await sendViaSmtp(config, student.email, latest.subject, latest.body, fromName);
        await sb.from('email_log').update({ sent: true }).eq('id', latest.id);
        return new Response(
          JSON.stringify({ ok: true, messageId: result.messageId, sent_to: student.email, email_id: latest.id }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
        );
      } catch (e) {
        return new Response(
          JSON.stringify({ ok: false, error: `Failed to send: ${e instanceof Error ? e.message : 'unknown error'}` }),
          { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
        );
      }
    }

    // --- Check SMTP configuration status (no send) ---
    if (action === 'status') {
      return new Response(
        JSON.stringify({
          configured: !!config,
          host: SMTP_HOST || null,
          port: SMTP_PORT || null,
          from: SMTP_FROM || null,
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
      );
    }

    throw new Error('Unknown action. Use: test, send, send_latest, or status.');
  } catch (err) {
    return new Response(
      JSON.stringify({ ok: false, error: err instanceof Error ? err.message : 'Unknown error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
    );
  }
});
