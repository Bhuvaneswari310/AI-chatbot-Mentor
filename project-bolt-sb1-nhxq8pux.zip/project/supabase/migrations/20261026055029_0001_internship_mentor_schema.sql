/*
# Internship Mentor System — Core Schema

1. Purpose
   A coordinator-managed internship mentoring platform. One coordinator
   registers interns, assigns projects with requirements, receives project
   submissions (with version tracking), runs AI reviews that produce
   actionable feedback + correction checklists + scores, chats with an
   AI mentor per student, schedules reviews (with optional Google Meet link),
   and sends personalized email notifications (rendered in-app since SMTP is
   not configured; an edge function renders the email body).

2. Design choice
   Single-coordinator app (no per-student sign-in required). Data is
   intentionally shared at the coordinator level, so policies use
   TO anon, authenticated with USING (true) — consistent with the
   bolt-database single-tenant guidance. The app has no login screen.

3. New tables
   - students: intern profile + project info + status
   - requirements: per-student project requirements (checklist items)
   - submissions: versioned project uploads (metadata + content)
   - review_items: individual findings inside a review (issues/checklist)
   - reviews: AI review of a submission (score, state, summary, checklist)
   - chat_messages: mentor chatbot conversation per student
   - schedules: review scheduling (date, venue, meet link, deadline)
   - email_log: rendered email notifications per student/review
   - settings: key/value app settings (coordinator contact, org name)

4. Security
   - RLS enabled on every table.
   - Grants to anon, authenticated (single-tenant, shared data).
   - service_role granted for edge-function writes.

5. Notes
   - Submissions store file metadata + pasted content (the sandbox has no
     file storage bucket); source code/reports are pasted as text so the AI
     can review them. This keeps the flow real without a storage backend.
*/

CREATE TABLE IF NOT EXISTS students (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text NOT NULL,
  domain text,
  project_title text NOT NULL,
  assigned_mentor text,
  skill_level text NOT NULL DEFAULT 'intermediate'
    CHECK (skill_level IN ('beginner','intermediate','advanced')),
  start_date date,
  expected_completion_date date,
  status text NOT NULL DEFAULT 'needs_correction'
    CHECK (status IN ('needs_correction','ready_for_review','approved')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE students ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE, DELETE ON students TO anon, authenticated, service_role;

DROP POLICY IF EXISTS "students_read" ON students;
CREATE POLICY "students_read" ON students FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "students_insert" ON students;
CREATE POLICY "students_insert" ON students FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "students_update" ON students;
CREATE POLICY "students_update" ON students FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "students_delete" ON students;
CREATE POLICY "students_delete" ON students FOR DELETE TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS students_status_idx ON students(status);
CREATE INDEX IF NOT EXISTS students_domain_idx ON students(domain);

CREATE TABLE IF NOT EXISTS requirements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id uuid NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  description text NOT NULL,
  is_mandatory boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE requirements ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE, DELETE ON requirements TO anon, authenticated, service_role;

DROP POLICY IF EXISTS "requirements_read" ON requirements;
CREATE POLICY "requirements_read" ON requirements FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "requirements_insert" ON requirements;
CREATE POLICY "requirements_insert" ON requirements FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "requirements_update" ON requirements;
CREATE POLICY "requirements_update" ON requirements FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "requirements_delete" ON requirements;
CREATE POLICY "requirements_delete" ON requirements FOR DELETE TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS requirements_student_idx ON requirements(student_id);

CREATE TABLE IF NOT EXISTS submissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id uuid NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  version integer NOT NULL,
  filename text NOT NULL,
  file_type text NOT NULL,
  content text,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(student_id, version)
);

ALTER TABLE submissions ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE, DELETE ON submissions TO anon, authenticated, service_role;

DROP POLICY IF EXISTS "submissions_read" ON submissions;
CREATE POLICY "submissions_read" ON submissions FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "submissions_insert" ON submissions;
CREATE POLICY "submissions_insert" ON submissions FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "submissions_update" ON submissions;
CREATE POLICY "submissions_update" ON submissions FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "submissions_delete" ON submissions;
CREATE POLICY "submissions_delete" ON submissions FOR DELETE TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS submissions_student_idx ON submissions(student_id, version DESC);

CREATE TABLE IF NOT EXISTS reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id uuid NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  submission_id uuid NOT NULL REFERENCES submissions(id) ON DELETE CASCADE,
  review_number integer NOT NULL,
  score integer NOT NULL DEFAULT 0 CHECK (score >= 0 AND score <= 100),
  state text NOT NULL DEFAULT 'needs_correction'
    CHECK (state IN ('needs_correction','ready_for_review','approved')),
  summary text,
  what_improved text,
  what_remains text,
  ai_model text,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE reviews ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE, DELETE ON reviews TO anon, authenticated, service_role;

DROP POLICY IF EXISTS "reviews_read" ON reviews;
CREATE POLICY "reviews_read" ON reviews FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "reviews_insert" ON reviews;
CREATE POLICY "reviews_insert" ON reviews FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "reviews_update" ON reviews;
CREATE POLICY "reviews_update" ON reviews FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "reviews_delete" ON reviews;
CREATE POLICY "reviews_delete" ON reviews FOR DELETE TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS reviews_student_idx ON reviews(student_id, review_number DESC);

CREATE TABLE IF NOT EXISTS review_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  review_id uuid NOT NULL REFERENCES reviews(id) ON DELETE CASCADE,
  severity text NOT NULL DEFAULT 'improvement'
    CHECK (severity IN ('error','warning','improvement','passed')),
  category text,
  title text NOT NULL,
  explanation text,
  fix text,
  resolved boolean NOT NULL DEFAULT false
);

ALTER TABLE review_items ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE, DELETE ON review_items TO anon, authenticated, service_role;

DROP POLICY IF EXISTS "review_items_read" ON review_items;
CREATE POLICY "review_items_read" ON review_items FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "review_items_insert" ON review_items;
CREATE POLICY "review_items_insert" ON review_items FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "review_items_update" ON review_items;
CREATE POLICY "review_items_update" ON review_items FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "review_items_delete" ON review_items;
CREATE POLICY "review_items_delete" ON review_items FOR DELETE TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS review_items_review_idx ON review_items(review_id);

CREATE TABLE IF NOT EXISTS chat_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id uuid NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  role text NOT NULL CHECK (role IN ('student','mentor')),
  content text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE chat_messages ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE, DELETE ON chat_messages TO anon, authenticated, service_role;

DROP POLICY IF EXISTS "chat_read" ON chat_messages;
CREATE POLICY "chat_read" ON chat_messages FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "chat_insert" ON chat_messages;
CREATE POLICY "chat_insert" ON chat_messages FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "chat_update" ON chat_messages;
CREATE POLICY "chat_update" ON chat_messages FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "chat_delete" ON chat_messages;
CREATE POLICY "chat_delete" ON chat_messages FOR DELETE TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS chat_student_idx ON chat_messages(student_id, created_at);

CREATE TABLE IF NOT EXISTS schedules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id uuid NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  review_at timestamptz NOT NULL,
  mode text NOT NULL DEFAULT 'online' CHECK (mode IN ('online','in_person')),
  venue text,
  meet_url text,
  submission_deadline date,
  reminder_interval_days integer NOT NULL DEFAULT 2,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE schedules ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE, DELETE ON schedules TO anon, authenticated, service_role;

DROP POLICY IF EXISTS "schedules_read" ON schedules;
CREATE POLICY "schedules_read" ON schedules FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "schedules_insert" ON schedules;
CREATE POLICY "schedules_insert" ON schedules FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "schedules_update" ON schedules;
CREATE POLICY "schedules_update" ON schedules FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "schedules_delete" ON schedules;
CREATE POLICY "schedules_delete" ON schedules FOR DELETE TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS schedules_student_idx ON schedules(student_id);
CREATE INDEX IF NOT EXISTS schedules_upcoming_idx ON schedules(review_at);

CREATE TABLE IF NOT EXISTS email_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id uuid NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  review_id uuid REFERENCES reviews(id) ON DELETE SET NULL,
  subject text NOT NULL,
  body text NOT NULL,
  email_type text NOT NULL DEFAULT 'review_update'
    CHECK (email_type IN ('review_update','reminder','overdue','resubmission','approval')),
  sent boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE email_log ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE, DELETE ON email_log TO anon, authenticated, service_role;

DROP POLICY IF EXISTS "email_log_read" ON email_log;
CREATE POLICY "email_log_read" ON email_log FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "email_log_insert" ON email_log;
CREATE POLICY "email_log_insert" ON email_log FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "email_update" ON email_log;
CREATE POLICY "email_update" ON email_log FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "email_delete" ON email_log;
CREATE POLICY "email_delete" ON email_log FOR DELETE TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS email_log_student_idx ON email_log(student_id, created_at DESC);

CREATE TABLE IF NOT EXISTS settings (
  key text PRIMARY KEY,
  value text NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE settings ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE, DELETE ON settings TO anon, authenticated, service_role;

DROP POLICY IF EXISTS "settings_read" ON settings;
CREATE POLICY "settings_read" ON settings FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "settings_insert" ON settings;
CREATE POLICY "settings_insert" ON settings FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "settings_update" ON settings;
CREATE POLICY "settings_update" ON settings FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "settings_delete" ON settings;
CREATE POLICY "settings_delete" ON settings FOR DELETE TO anon, authenticated USING (true);

INSERT INTO settings (key, value) VALUES
  ('org_name', 'Acme Internship Program'),
  ('coordinator_name', 'Program Coordinator'),
  ('coordinator_email', 'coordinator@example.com'),
  ('coordinator_phone', '')
ON CONFLICT (key) DO NOTHING;
